# 🕹️ 2D Multiplayer Game Prototype (Client Prediction + Server Authority)

## 🎯 Goal

Build a **real-time 2D multiplayer game** with:

* Smooth player movement
* Projectile shooting
* Server authoritative state
* Client-side prediction
* Reconciliation & interpolation

---

## 🧠 Core Concepts

### 1. Client-Side Prediction

Client applies input immediately instead of waiting for server.
This removes input lag. ([Wikipedia][1])

### 2. Server Authority

Server is the source of truth:

* Position
* Collisions
* Damage

### 3. Server Reconciliation

Client:

* Receives server state
* Reapplies unconfirmed inputs

### 4. Interpolation

Smooths movement of other players.

---

## 🏗️ Architecture

```
Client (React + Canvas)
   ↓ send input
Server (Node + WebSocket)
   ↓ send state
Client renders
```

---

## 📁 Suggested Project Structure

```
/client
  /src
    Game.tsx
    useGameLoop.ts
    useSocket.ts
    physics.ts

/server
  server.js
  gameLoop.js
  physics.js
```

---

## ⚙️ Server Implementation

### State

```js
const players = {};
let projectiles = [];
```

---

### Handle Input

```js
if (data.type === "INPUT") {
  const p = players[data.playerId];

  if (data.input.forward) p.y += 5;
  if (data.input.left) p.x -= 5;

  p.lastProcessedInput = data.seq;
}
```

---

### Shoot Projectile

```js
if (data.type === "SHOOT") {
  const p = players[data.playerId];

  projectiles.push({
    id: Date.now(),
    x: p.x,
    y: p.y,
    vx: Math.cos(data.angle) * 10,
    vy: Math.sin(data.angle) * 10,
  });
}
```

---

### Game Loop (60 FPS)

```js
setInterval(() => {
  projectiles.forEach(p => {
    p.x += p.vx;
    p.y += p.vy;
  });

  broadcast({
    type: "STATE",
    players,
    projectiles
  });
}, 16);
```

---

## 🎮 Client Implementation

### State

```js
let player = { x: 0, y: 0 };
let inputSeq = 0;
let pendingInputs = [];
```

---

### Send Input + Predict

```js
function sendInput(input) {
  inputSeq++;

  socket.send(JSON.stringify({
    type: "INPUT",
    seq: inputSeq,
    input
  }));

  applyInput(player, input);

  pendingInputs.push({ seq: inputSeq, input });
}
```

---

### Apply Input

```js
function applyInput(player, input) {
  if (input.forward) player.y += 5;
  if (input.left) player.x -= 5;
}
```

---

### Reconciliation

```js
function handleServerState(serverPlayer) {
  player.x = serverPlayer.x;
  player.y = serverPlayer.y;

  pendingInputs = pendingInputs.filter(
    i => i.seq > serverPlayer.lastProcessedInput
  );

  pendingInputs.forEach(i => {
    applyInput(player, i.input);
  });
}
```

---

## 🔫 Shooting (Client Prediction)

```js
function shoot() {
  const proj = {
    x: player.x,
    y: player.y,
    vx: Math.cos(angle) * 10,
    vy: Math.sin(angle) * 10,
  };

  localProjectiles.push(proj);

  socket.send(JSON.stringify({
    type: "SHOOT",
    angle
  }));
}
```

---

## 🎥 Interpolation (Other Players)

```js
function lerp(a, b, t) {
  return a + (b - a) * t;
}
```

```js
const x = lerp(prev.x, next.x, t);
const y = lerp(prev.y, next.y, t);
```

---

## 🔁 Game Loop (Client)

```js
function gameLoop() {
  update();
  render();
  requestAnimationFrame(gameLoop);
}
```

---

## 💥 Collision (Server Only)

```js
if (distance(projectile, player) < hitRadius) {
  player.hp -= 10;
}
```

---

## 🚀 Features to Add Later

* Rotation-based movement (tank style)
* Projectile lifetime
* Explosion radius
* Lag compensation (rewind)
* Delta time physics

---

## 🧠 Mental Model

| Component | Responsibility         |
| --------- | ---------------------- |
| Client    | Input + Prediction     |
| Server    | Truth + Physics        |
| Client    | Correction + Rendering |

---

## ✅ Success Criteria

* Movement feels instant
* No jitter for other players
* No cheating possible
* Projectiles sync correctly

---

## 🔥 Tip for Codex

Ask Codex:

* "Generate React canvas rendering for player movement"
* "Add WebSocket client hook"
* "Convert physics to delta time"

---

## 🎯 Final Goal

Build a **Smash Karts–like prototype** with:

* Smooth movement
* Real-time shooting
* Multiplayer sync

---

[1]: https://en.wikipedia.org/wiki/Client-side_prediction?utm_source=chatgpt.com "Client-side prediction"
