import os from "node:os";
import path from "node:path";
import { fileURLToPath } from "node:url";
import express from "express";
import { Room, Server } from "colyseus";
import { MapSchema, Schema, defineTypes } from "@colyseus/schema";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const publicDir = path.join(__dirname, "public");
const port = Number(process.env.PORT || 3003);
const host = process.env.HOST || "0.0.0.0";
const tickRate = 60;
const snapshotRate = 20;
const world = { width: 1600, height: 1000 };

let nextPlayerNumber = 1;

class WorldState extends Schema {
  constructor() {
    super();
    this.width = world.width;
    this.height = world.height;
  }
}

defineTypes(WorldState, {
  width: "number",
  height: "number"
});

class PlayerState extends Schema {
  constructor() {
    super();
    this.id = "";
    this.name = "";
    this.x = 0;
    this.y = 0;
    this.angle = 0;
    this.vx = 0;
    this.vy = 0;
    this.hp = 100;
    this.score = 0;
    this.color = "";
    this.lastProcessedInput = 0;
    this.respawning = false;
    this.fireCooldown = 0;
    this.respawnTimer = 0;
    this.input = { up: false, down: false, left: false, right: false, boost: false };
  }
}

defineTypes(PlayerState, {
  id: "string",
  name: "string",
  x: "number",
  y: "number",
  angle: "number",
  vx: "number",
  vy: "number",
  hp: "number",
  score: "number",
  color: "string",
  lastProcessedInput: "number",
  respawning: "boolean"
});

class ProjectileState extends Schema {
  constructor() {
    super();
    this.id = "";
    this.ownerId = "";
    this.x = 0;
    this.y = 0;
    this.vx = 0;
    this.vy = 0;
    this.life = 0;
  }
}

defineTypes(ProjectileState, {
  id: "string",
  ownerId: "string",
  x: "number",
  y: "number",
  vx: "number",
  vy: "number"
});

class KartArenaState extends Schema {
  constructor() {
    super();
    this.world = new WorldState();
    this.players = new MapSchema();
    this.projectiles = new MapSchema();
  }
}

defineTypes(KartArenaState, {
  world: WorldState,
  players: { map: PlayerState },
  projectiles: { map: ProjectileState }
});

class KartRoom extends Room {
  state = new KartArenaState();
  maxClients = 16;
  patchRate = 1000 / snapshotRate;
  nextProjectileId = 1;

  onCreate() {
    this.onMessage("input", (client, data) => {
      const player = this.state.players.get(client.sessionId);
      if (!player) return;

      player.input = {
        up: Boolean(data.input?.up),
        down: Boolean(data.input?.down),
        left: Boolean(data.input?.left),
        right: Boolean(data.input?.right),
        boost: Boolean(data.input?.boost)
      };
      player.lastProcessedInput = Number(data.seq) || player.lastProcessedInput;
    });

    this.onMessage("shoot", (client, data) => {
      const player = this.state.players.get(client.sessionId);
      if (!player) return;

      this.shoot(player, Number(data.angle) || player.angle, data.shotId);
    });

    this.setSimulationInterval(deltaTime => {
      this.update(Math.min(0.05, deltaTime / 1000));
      this.roundSyncedValues();
    }, 1000 / tickRate);
  }

  onJoin(client) {
    const player = createPlayer(client.sessionId);
    this.state.players.set(client.sessionId, player);

    client.send("welcome", { id: client.sessionId, world });
    this.broadcast("notice", `Player ${player.name} joined`);
  }

  onLeave(client) {
    const player = this.state.players.get(client.sessionId);
    this.state.players.delete(client.sessionId);

    if (player) {
      this.broadcast("notice", `${player.name} left`);
    }
  }

  update(dt) {
    for (const player of this.state.players.values()) {
      if (player.respawnTimer > 0) {
        player.respawnTimer -= dt;
        player.respawning = true;
        if (player.respawnTimer <= 0) this.respawn(player);
        continue;
      }

      player.respawning = false;
      player.fireCooldown = Math.max(0, player.fireCooldown - dt);

      const turnSpeed = 4.2;
      if (player.input.left) player.angle -= turnSpeed * dt;
      if (player.input.right) player.angle += turnSpeed * dt;
      player.angle = clampAngle(player.angle);

      const thrust = player.input.boost ? 760 : 520;
      const reverse = 320;
      if (player.input.up) {
        player.vx += Math.cos(player.angle) * thrust * dt;
        player.vy += Math.sin(player.angle) * thrust * dt;
      }
      if (player.input.down) {
        player.vx -= Math.cos(player.angle) * reverse * dt;
        player.vy -= Math.sin(player.angle) * reverse * dt;
      }

      const maxSpeed = player.input.boost ? 430 : 330;
      const speed = Math.hypot(player.vx, player.vy);
      if (speed > maxSpeed) {
        player.vx = (player.vx / speed) * maxSpeed;
        player.vy = (player.vy / speed) * maxSpeed;
      }

      player.vx *= 0.985;
      player.vy *= 0.985;
      player.x = clamp(player.x + player.vx * dt, 28, world.width - 28);
      player.y = clamp(player.y + player.vy * dt, 28, world.height - 28);
    }

    for (const projectile of this.state.projectiles.values()) {
      projectile.life -= dt;
      projectile.x += projectile.vx * dt;
      projectile.y += projectile.vy * dt;

      if (
        projectile.life <= 0 ||
        projectile.x < 0 ||
        projectile.y < 0 ||
        projectile.x > world.width ||
        projectile.y > world.height
      ) {
        this.state.projectiles.delete(projectile.id);
        continue;
      }

      for (const player of this.state.players.values()) {
        if (player.id === projectile.ownerId || player.respawnTimer > 0) continue;

        if (Math.hypot(player.x - projectile.x, player.y - projectile.y) < 30) {
          player.hp -= 25;
          this.state.projectiles.delete(projectile.id);

          if (player.hp <= 0) {
            const owner = this.state.players.get(projectile.ownerId);
            if (owner) owner.score += 1;
            player.respawnTimer = 1.5;
            player.respawning = true;
          }
          break;
        }
      }
    }
  }

  shoot(player, angle, shotId) {
    if (player.fireCooldown > 0 || player.respawnTimer > 0) return;

    player.fireCooldown = 0.28;
    const projectile = new ProjectileState();
    projectile.id = String(this.nextProjectileId++);
    projectile.ownerId = player.id;
    projectile.x = player.x + Math.cos(angle) * 34;
    projectile.y = player.y + Math.sin(angle) * 34;
    projectile.vx = Math.cos(angle) * 680 + player.vx * 0.3;
    projectile.vy = Math.sin(angle) * 680 + player.vy * 0.3;
    projectile.life = 1.35;
    this.state.projectiles.set(projectile.id, projectile);

    const client = this.clients.find(candidate => candidate.sessionId === player.id);
    client?.send("shoot_ack", {
      shotId,
      projectile: serializeProjectile(projectile)
    });
  }

  respawn(player) {
    player.hp = 100;
    player.x = 120 + Math.random() * (world.width - 240);
    player.y = 120 + Math.random() * (world.height - 240);
    player.vx = 0;
    player.vy = 0;
    player.angle = Math.random() * Math.PI * 2;
    player.input = { up: false, down: false, left: false, right: false, boost: false };
    player.respawnTimer = 0;
    player.respawning = false;
  }

  roundSyncedValues() {
    for (const player of this.state.players.values()) {
      player.x = round(player.x, 2);
      player.y = round(player.y, 2);
      player.angle = round(player.angle, 3);
      player.vx = round(player.vx, 2);
      player.vy = round(player.vy, 2);
    }

    for (const projectile of this.state.projectiles.values()) {
      projectile.x = round(projectile.x, 2);
      projectile.y = round(projectile.y, 2);
      projectile.vx = round(projectile.vx, 2);
      projectile.vy = round(projectile.vy, 2);
    }
  }
}

function createPlayer(id) {
  const spawnPad = 140;
  const hue = Math.floor(Math.random() * 360);
  const player = new PlayerState();

  player.id = id;
  player.name = `P${nextPlayerNumber++}`;
  player.x = spawnPad + Math.random() * (world.width - spawnPad * 2);
  player.y = spawnPad + Math.random() * (world.height - spawnPad * 2);
  player.angle = Math.random() * Math.PI * 2;
  player.color = `hsl(${hue}, 78%, 56%)`;

  return player;
}

function serializeProjectile(projectile) {
  return {
    id: projectile.id,
    ownerId: projectile.ownerId,
    x: projectile.x,
    y: projectile.y,
    vx: projectile.vx,
    vy: projectile.vy
  };
}

function round(value, places) {
  const multiplier = 10 ** places;
  return Math.round(value * multiplier) / multiplier;
}

function clamp(value, min, max) {
  return Math.max(min, Math.min(max, value));
}

function clampAngle(angle) {
  const full = Math.PI * 2;
  return ((angle % full) + full) % full;
}

const gameServer = new Server({
  express: app => {
    app.use(express.static(publicDir));
    app.get("/", (_req, res) => res.sendFile(path.join(publicDir, "index.html")));
  }
});

gameServer.define("kart_arena", KartRoom);

gameServer.listen(port, host).then(() => {
  console.log(`Prototype running locally at http://127.0.0.1:${port}`);

  for (const address of getLanAddresses()) {
    console.log(`LAN access: http://${address}:${port}`);
  }
});

function getLanAddresses() {
  return Object.values(os.networkInterfaces())
    .flat()
    .filter(address => address && address.family === "IPv4" && !address.internal)
    .map(address => address.address);
}
