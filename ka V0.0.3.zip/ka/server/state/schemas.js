import { MapSchema, Schema, defineTypes } from "@colyseus/schema";
import { worldConfig } from "../config/gameConfig.js";

export class WorldState extends Schema {
  constructor() {
    super();
    this.width = worldConfig.width;
    this.height = worldConfig.height;
  }
}

defineTypes(WorldState, {
  width: "number",
  height: "number"
});

export class PlayerState extends Schema {
  constructor() {
    super();
    this.id = "";
    this.name = "";
    this.x = 0;
    this.y = 0;
    this.angle = 0;
    this.vx = 0;
    this.vy = 0;
    this.hp = 100;
    this.score = 0;
    this.color = "";
    this.lastProcessedInput = 0;
    this.respawning = false;
    this.turning = 0;
    this.fireCooldown = 0;
    this.respawnTimer = 0;
    this.input = { up: false, down: false, left: false, right: false, boost: false };
  }
}

defineTypes(PlayerState, {
  id: "string",
  name: "string",
  x: "number",
  y: "number",
  angle: "number",
  vx: "number",
  vy: "number",
  hp: "number",
  score: "number",
  color: "string",
  lastProcessedInput: "number",
  respawning: "boolean",
  turning: "number"
});

export class ProjectileState extends Schema {
  constructor() {
    super();
    this.id = "";
    this.ownerId = "";
    this.x = 0;
    this.y = 0;
    this.vx = 0;
    this.vy = 0;
    this.life = 0;
  }
}

defineTypes(ProjectileState, {
  id: "string",
  ownerId: "string",
  x: "number",
  y: "number",
  vx: "number",
  vy: "number"
});

export class SupplyBoxState extends Schema {
  constructor() {
    super();
    this.id = "";
    this.x = 0;
    this.y = 0;
    this.active = true;
    this.respawnTimer = 0;
  }
}

defineTypes(SupplyBoxState, {
  id: "string",
  x: "number",
  y: "number",
  active: "boolean"
});

export class KartArenaState extends Schema {
  constructor() {
    super();
    this.world = new WorldState();
    this.players = new MapSchema();
    this.projectiles = new MapSchema();
    this.supplyBoxes = new MapSchema();
  }
}

defineTypes(KartArenaState, {
  world: WorldState,
  players: { map: PlayerState },
  projectiles: { map: ProjectileState },
  supplyBoxes: { map: SupplyBoxState }
});
