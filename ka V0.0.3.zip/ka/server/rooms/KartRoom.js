import { Room } from "colyseus";
import { networkConfig, playerConfig, projectileConfig, supplyBoxConfig, worldConfig } from "../config/gameConfig.js";
import { recordMatch, upsertGuestPlayer } from "../db/mongo.js";
import { KartArenaState, PlayerState, SupplyBoxState } from "../state/schemas.js";
import { createProjectile, serializeProjectile } from "../simulation/combat.js";
import { placeSupplyBox } from "../simulation/pickups.js";
import { roundSyncedValues, updateWorld } from "../simulation/world.js";

let nextPlayerNumber = 1;

export class KartRoom extends Room {
  state = new KartArenaState();
  maxClients = networkConfig.maxClients;
  patchRate = 1000 / networkConfig.snapshotRate;
  nextProjectileId = 1;
  startedAt = new Date();
  participants = new Map();

  onCreate() {
    this.spawnSupplyBoxes();
    this.registerMessages();

    this.setSimulationInterval(deltaTime => {
      updateWorld(this.state, Math.min(0.05, deltaTime / 1000), {
        onPlayerKilled: event => this.recordKill(event)
      });
      roundSyncedValues(this.state);
    }, 1000 / networkConfig.tickRate);
  }

  async onJoin(client, options = {}) {
    const fallbackName = `P${nextPlayerNumber++}`;
    const guestId = normalizeGuestId(options.guestId, client.sessionId);
    const profile = await upsertGuestPlayer(guestId, fallbackName);
    const player = createPlayer(client.sessionId, profile?.name || fallbackName);
    this.state.players.set(client.sessionId, player);
    this.participants.set(client.sessionId, {
      guestId,
      name: player.name,
      joinedAt: new Date(),
      leftAt: null,
      score: 0,
      kills: 0,
      deaths: 0
    });

    client.send("welcome", { id: client.sessionId, world: worldConfig });
    this.broadcast("notice", `Player ${player.name} joined`);
  }

  onLeave(client) {
    const player = this.state.players.get(client.sessionId);
    const participant = this.participants.get(client.sessionId);
    if (participant) {
      participant.leftAt = new Date();
      participant.score = player?.score || participant.score;
    }
    this.state.players.delete(client.sessionId);

    if (player) {
      this.broadcast("notice", `${player.name} left`);
    }
  }

  async onDispose() {
    const endedAt = new Date();
    const participants = Array.from(this.participants.entries()).map(([sessionId, participant]) => {
      const player = this.state.players.get(sessionId);

      return {
        guestId: participant.guestId,
        sessionId,
        name: player?.name || participant.name,
        score: player?.score || participant.score,
        kills: participant.kills,
        deaths: participant.deaths,
        joinedAt: participant.joinedAt,
        leftAt: participant.leftAt || endedAt
      };
    });

    await recordMatch({
      roomId: this.roomId,
      startedAt: this.startedAt,
      endedAt,
      participants
    });
  }

  spawnSupplyBoxes() {
    for (let i = 1; i <= supplyBoxConfig.count; i += 1) {
      const supplyBox = new SupplyBoxState();
      supplyBox.id = String(i);
      placeSupplyBox(supplyBox);
      this.state.supplyBoxes.set(supplyBox.id, supplyBox);
    }
  }

  registerMessages() {
    this.onMessage("input", (client, data) => {
      const player = this.state.players.get(client.sessionId);
      if (!player) return;

      player.input = {
        up: Boolean(data.input?.up),
        down: Boolean(data.input?.down),
        left: Boolean(data.input?.left),
        right: Boolean(data.input?.right),
        boost: Boolean(data.input?.boost)
      };
      player.lastProcessedInput = Number(data.seq) || player.lastProcessedInput;
    });

    this.onMessage("shoot", (client, data) => {
      const player = this.state.players.get(client.sessionId);
      if (!player) return;

      this.shoot(player, data.shotId);
    });

    this.onMessage("ping", (client, data) => {
      client.send("pong", { sentAt: data.sentAt });
    });
  }

  shoot(player, shotId) {
    if (player.fireCooldown > 0 || player.respawnTimer > 0) return;

    player.fireCooldown = projectileConfig.fireCooldownSeconds;
    const projectile = createProjectile(this.nextProjectileId++, player);
    this.state.projectiles.set(projectile.id, projectile);

    const client = this.clients.find(candidate => candidate.sessionId === player.id);
    client?.send("shoot_ack", {
      shotId,
      projectile: serializeProjectile(projectile)
    });
  }

  recordKill({ killer, victim }) {
    const victimParticipant = this.participants.get(victim.id);
    if (victimParticipant) victimParticipant.deaths += 1;

    if (!killer) return;

    const killerParticipant = this.participants.get(killer.id);
    if (killerParticipant) killerParticipant.kills += 1;
  }
}

function createPlayer(id, name) {
  const hue = Math.floor(Math.random() * 360);
  const player = new PlayerState();

  player.id = id;
  player.name = name;
  player.x = playerConfig.spawnPadding + Math.random() * (worldConfig.width - playerConfig.spawnPadding * 2);
  player.y = playerConfig.spawnPadding + Math.random() * (worldConfig.height - playerConfig.spawnPadding * 2);
  player.angle = Math.random() * Math.PI * 2;
  player.color = `hsl(${hue}, 78%, 56%)`;

  return player;
}

function normalizeGuestId(guestId, fallbackId) {
  const value = typeof guestId === "string" ? guestId.trim() : "";
  if (/^guest_[a-zA-Z0-9_-]{8,80}$/.test(value)) return value;
  return `guest_${fallbackId}`;
}
