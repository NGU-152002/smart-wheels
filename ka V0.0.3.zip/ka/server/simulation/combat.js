import { playerConfig, projectileConfig, worldConfig } from "../config/gameConfig.js";
import { ProjectileState } from "../state/schemas.js";

export function createProjectile(id, player) {
  const angle = player.angle;
  const projectile = new ProjectileState();

  projectile.id = String(id);
  projectile.ownerId = player.id;
  projectile.x = player.x + Math.cos(angle) * projectileConfig.spawnOffset;
  projectile.y = player.y + Math.sin(angle) * projectileConfig.spawnOffset;
  projectile.vx = Math.cos(angle) * projectileConfig.speed + player.vx * projectileConfig.inheritedVelocityScale;
  projectile.vy = Math.sin(angle) * projectileConfig.speed + player.vy * projectileConfig.inheritedVelocityScale;
  projectile.life = projectileConfig.lifetimeSeconds;

  return projectile;
}

export function updateProjectiles(state, dt, events = {}) {
  for (const projectile of state.projectiles.values()) {
    projectile.life -= dt;
    projectile.x += projectile.vx * dt;
    projectile.y += projectile.vy * dt;

    if (shouldRemoveProjectile(projectile)) {
      state.projectiles.delete(projectile.id);
      continue;
    }

    applyProjectileHits(state, projectile, events);
  }
}

export function serializeProjectile(projectile) {
  return {
    id: projectile.id,
    ownerId: projectile.ownerId,
    x: projectile.x,
    y: projectile.y,
    vx: projectile.vx,
    vy: projectile.vy
  };
}

function shouldRemoveProjectile(projectile) {
  return (
    projectile.life <= 0 ||
    projectile.x < 0 ||
    projectile.y < 0 ||
    projectile.x > worldConfig.width ||
    projectile.y > worldConfig.height
  );
}

function applyProjectileHits(state, projectile, events) {
  for (const player of state.players.values()) {
    if (player.id === projectile.ownerId || player.respawnTimer > 0) continue;

    if (Math.hypot(player.x - projectile.x, player.y - projectile.y) < projectileConfig.hitRadius) {
      player.hp -= projectileConfig.damage;
      state.projectiles.delete(projectile.id);

      if (player.hp <= 0) {
        const owner = state.players.get(projectile.ownerId);
        if (owner) owner.score += 1;
        events.onPlayerKilled?.({ killer: owner, victim: player, projectile });
        player.respawnTimer = playerConfig.respawnSeconds;
        player.respawning = true;
      }
      break;
    }
  }
}
