import { playerConfig, supplyBoxConfig, worldConfig } from "../config/gameConfig.js";

export function placeSupplyBox(supplyBox) {
  supplyBox.x = supplyBoxConfig.spawnPadding + Math.random() * (worldConfig.width - supplyBoxConfig.spawnPadding * 2);
  supplyBox.y = supplyBoxConfig.spawnPadding + Math.random() * (worldConfig.height - supplyBoxConfig.spawnPadding * 2);
  supplyBox.respawnTimer = 0;
}

export function collectSupplyBoxes(player, supplyBoxes) {
  if (player.hp >= playerConfig.maxHp || player.respawnTimer > 0) return;

  for (const supplyBox of supplyBoxes.values()) {
    if (!supplyBox.active) continue;

    if (Math.hypot(player.x - supplyBox.x, player.y - supplyBox.y) <= supplyBoxConfig.pickupRadius) {
      player.hp = Math.min(playerConfig.maxHp, player.hp + supplyBoxConfig.healAmount);
      supplyBox.active = false;
      supplyBox.respawnTimer = supplyBoxConfig.respawnSeconds;
    }
  }
}

export function updateSupplyBoxes(supplyBoxes, dt) {
  for (const supplyBox of supplyBoxes.values()) {
    if (supplyBox.active) continue;

    supplyBox.respawnTimer -= dt;
    if (supplyBox.respawnTimer <= 0) {
      placeSupplyBox(supplyBox);
      supplyBox.active = true;
    }
  }
}
