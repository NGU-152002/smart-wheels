import { playerConfig, worldConfig } from "../config/gameConfig.js";
import { clamp, clampAngle } from "../utils/math.js";

export function updatePlayerMovement(player, dt) {
  player.fireCooldown = Math.max(0, player.fireCooldown - dt);

  player.turning = (player.input.right ? 1 : 0) - (player.input.left ? 1 : 0);
  if (player.input.left) player.angle -= playerConfig.turnSpeed * dt;
  if (player.input.right) player.angle += playerConfig.turnSpeed * dt;
  player.angle = clampAngle(player.angle);

  const thrust = player.input.boost ? playerConfig.boostThrust : playerConfig.thrust;
  if (player.input.down) {
    player.vx -= Math.cos(player.angle) * playerConfig.reverseThrust * dt;
    player.vy -= Math.sin(player.angle) * playerConfig.reverseThrust * dt;
  } else {
    player.vx += Math.cos(player.angle) * thrust * dt;
    player.vy += Math.sin(player.angle) * thrust * dt;
  }

  const maxSpeed = player.input.boost ? playerConfig.boostMaxSpeed : playerConfig.maxSpeed;
  const speed = Math.hypot(player.vx, player.vy);
  if (speed > maxSpeed) {
    player.vx = (player.vx / speed) * maxSpeed;
    player.vy = (player.vy / speed) * maxSpeed;
  }

  player.vx *= playerConfig.friction;
  player.vy *= playerConfig.friction;
  player.x = clamp(player.x + player.vx * dt, playerConfig.boundsRadius, worldConfig.width - playerConfig.boundsRadius);
  player.y = clamp(player.y + player.vy * dt, playerConfig.boundsRadius, worldConfig.height - playerConfig.boundsRadius);
}

export function respawnPlayer(player) {
  player.hp = playerConfig.maxHp;
  player.x = playerConfig.respawnPadding + Math.random() * (worldConfig.width - playerConfig.respawnPadding * 2);
  player.y = playerConfig.respawnPadding + Math.random() * (worldConfig.height - playerConfig.respawnPadding * 2);
  player.vx = 0;
  player.vy = 0;
  player.angle = Math.random() * Math.PI * 2;
  player.input = { up: false, down: false, left: false, right: false, boost: false };
  player.respawnTimer = 0;
  player.respawning = false;
}
