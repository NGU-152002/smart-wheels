import { collectSupplyBoxes, updateSupplyBoxes } from "./pickups.js";
import { respawnPlayer, updatePlayerMovement } from "./movement.js";
import { updateProjectiles } from "./combat.js";
import { round } from "../utils/math.js";

export function updateWorld(state, dt, events = {}) {
  for (const player of state.players.values()) {
    if (player.respawnTimer > 0) {
      player.respawnTimer -= dt;
      player.respawning = true;
      if (player.respawnTimer <= 0) respawnPlayer(player);
      continue;
    }

    player.respawning = false;
    updatePlayerMovement(player, dt);
    collectSupplyBoxes(player, state.supplyBoxes);
  }

  updateSupplyBoxes(state.supplyBoxes, dt);
  updateProjectiles(state, dt, events);
}

export function roundSyncedValues(state) {
  for (const player of state.players.values()) {
    player.x = round(player.x, 2);
    player.y = round(player.y, 2);
    player.angle = round(player.angle, 3);
    player.vx = round(player.vx, 2);
    player.vy = round(player.vy, 2);
  }

  for (const projectile of state.projectiles.values()) {
    projectile.x = round(projectile.x, 2);
    projectile.y = round(projectile.y, 2);
    projectile.vx = round(projectile.vx, 2);
    projectile.vy = round(projectile.vy, 2);
  }

  for (const supplyBox of state.supplyBoxes.values()) {
    supplyBox.x = round(supplyBox.x, 2);
    supplyBox.y = round(supplyBox.y, 2);
  }
}
