export function round(value, places) {
  const multiplier = 10 ** places;
  return Math.round(value * multiplier) / multiplier;
}

export function clamp(value, min, max) {
  return Math.max(min, Math.min(max, value));
}

export function clampAngle(angle) {
  const full = Math.PI * 2;
  return ((angle % full) + full) % full;
}
