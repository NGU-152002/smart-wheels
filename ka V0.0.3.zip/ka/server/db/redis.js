import { Redis } from "ioredis";
import { RedisDriver } from "@colyseus/redis-driver";
import { RedisPresence } from "@colyseus/redis-presence";

export function createRedisBackends(redisUrl) {
  const options = {
    maxRetriesPerRequest: 1,
    retryStrategy: () => null
  };
  const driverClient = new Redis(redisUrl, options);
  const presenceClient = new Redis(redisUrl, options);
  const driver = new RedisDriver(driverClient);
  const presence = new RedisPresence(presenceClient);

  attachRedisErrorLogger(driverClient, "Redis driver");
  attachRedisErrorLogger(presenceClient, "Redis presence publisher");
  attachRedisErrorLogger(presence.sub, "Redis presence subscriber");

  return { driver, presence };
}

function attachRedisErrorLogger(client, label) {
  let logged = false;

  client.on("error", error => {
    if (logged) return;
    logged = true;
    console.error(`${label} connection error: ${error.message}`);
  });
}
