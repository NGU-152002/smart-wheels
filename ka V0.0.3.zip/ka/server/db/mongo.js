import { MongoClient } from "mongodb";

let client = null;
let db = null;

export async function connectMongo() {
  const uri = requireEnv("MONGO_URI");
  const dbName = requireEnv("MONGO_DB_NAME");

  client = new MongoClient(uri);
  await client.connect();
  db = client.db(dbName);
  await createIndexes();

  return db;
}

export async function closeMongo() {
  if (client) {
    await client.close();
    client = null;
    db = null;
  }
}

export function getCollections() {
  if (!db) {
    throw new Error("MongoDB has not been initialized. Call connectMongo() before starting the server.");
  }

  return {
    players: db.collection("players"),
    matches: db.collection("matches")
  };
}

export async function upsertGuestPlayer(guestId, fallbackName) {
  const now = new Date();
  const { players } = getCollections();

  await players.updateOne(
    { guestId },
    {
      $set: { lastSeenAt: now },
      $setOnInsert: {
        guestId,
        name: fallbackName,
        gamesPlayed: 0,
        kills: 0,
        deaths: 0,
        totalScore: 0,
        bestScore: 0,
        createdAt: now
      }
    },
    { upsert: true }
  );

  return players.findOne({ guestId });
}

export async function recordMatch({ roomId, startedAt, endedAt, participants }) {
  if (!participants.length) return;

  const { matches, players } = getCollections();

  await matches.insertOne({
    roomId,
    startedAt,
    endedAt,
    participants
  });

  const operations = participants.map(participant => ({
    updateOne: {
      filter: { guestId: participant.guestId },
      update: {
        $set: {
          name: participant.name,
          lastSeenAt: endedAt
        },
        $inc: {
          gamesPlayed: 1,
          kills: participant.kills,
          deaths: participant.deaths,
          totalScore: participant.score
        },
        $max: {
          bestScore: participant.score
        },
        $setOnInsert: {
          guestId: participant.guestId,
          createdAt: endedAt
        }
      },
      upsert: true
    }
  }));

  await players.bulkWrite(operations, { ordered: false });
}

async function createIndexes() {
  const { players, matches } = getCollections();

  await Promise.all([
    players.createIndex({ guestId: 1 }, { unique: true }),
    players.createIndex({ bestScore: -1 }),
    matches.createIndex({ endedAt: -1 }),
    matches.createIndex({ roomId: 1 })
  ]);
}

function requireEnv(name) {
  const value = process.env[name];
  if (!value) {
    throw new Error(`${name} is required`);
  }
  return value;
}
