export const networkConfig = {
  port: Number(process.env.PORT || 3003),
  host: process.env.HOST || "0.0.0.0",
  tickRate: 60,
  snapshotRate: 20,
  maxClients: 16
};

export const worldConfig = {
  width: 1600,
  height: 1000
};

export const playerConfig = {
  boundsRadius: 38,
  spawnPadding: 140,
  respawnPadding: 120,
  respawnSeconds: 1.5,
  maxHp: 100,
  turnSpeed: 2.0,
  thrust: 520,
  boostThrust: 760,
  reverseThrust: 320,
  maxSpeed: 330,
  boostMaxSpeed: 430,
  friction: 0.985
};

export const projectileConfig = {
  damage: 25,
  hitRadius: 30,
  spawnOffset: 34,
  speed: 680,
  inheritedVelocityScale: 0.3,
  lifetimeSeconds: 1.35,
  fireCooldownSeconds: 0.28
};

export const supplyBoxConfig = {
  count: 6,
  healAmount: 25,
  pickupRadius: 42,
  respawnSeconds: 3,
  spawnPadding: 90
};
