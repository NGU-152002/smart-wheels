import { loadGameAssets } from "./client/assets.js";
import { world, projectileConfig } from "./client/config.js";
import { getDom, resizeCanvas } from "./client/dom.js";
import { createDriftSmoke } from "./client/effects/driftSmoke.js";
import { createInputController } from "./client/input/controls.js";
import { createNetworkClient } from "./client/net/connection.js";
import { createSnapshotBuffer } from "./client/net/snapshots.js";
import { predictPlayer, reconcilePlayer } from "./client/prediction/playerPrediction.js";
import { createPredictedProjectile } from "./client/prediction/projectiles.js";
import { createRenderer } from "./client/render/renderer.js";
import {
  clearNetworkPing,
  renderScoreboard,
  setStatus,
  showNetworkPing,
  showShotPing
} from "./client/ui/hud.js";

const dom = getDom();
const assets = loadGameAssets();
const pendingInputs = [];
const pendingShots = new Map();
const predictedProjectiles = new Map();
const snapshotBuffer = createSnapshotBuffer();
const localPlayer = { current: null };

let inputSeq = 0;
let shotSeq = 0;
let nextShootAt = 0;
let lastFrame = performance.now();

const network = createNetworkClient({
  world,
  onConnected: () => {
    setStatus(dom.statusEl, "Connected");
  },
  onDisconnected: failed => {
    clearNetworkPing(dom.networkPingEl);
    setStatus(dom.statusEl, failed ? "Connection failed. Reconnecting..." : "Disconnected. Reconnecting...");
  },
  onSnapshot: applySnapshot,
  onNotice: text => {
    setStatus(dom.statusEl, text);
    setTimeout(() => {
      if (network.getRoom()) setStatus(dom.statusEl, "Connected");
    }, 1200);
  },
  onNetworkPing: rtt => showNetworkPing(dom.networkPingEl, rtt),
  onShootAck: handleShootAck
});

const input = createInputController({
  canvas: dom.canvas,
  fullscreenButton: dom.fullscreenButton,
  joystickEl: dom.joystickEl,
  joystickKnobEl: dom.joystickKnobEl,
  boostButton: dom.boostButton,
  shootButton: dom.shootButton,
  onResize: () => resizeCanvas(dom.canvas),
  onShoot: shoot,
  onStatus: text => setStatus(dom.statusEl, text)
});

const renderer = createRenderer({
  canvas: dom.canvas,
  ctx: dom.ctx,
  assets,
  driftSmoke: createDriftSmoke(),
  predictedProjectiles,
  getLocalPlayer: () => localPlayer.current,
  getMyId: () => network.getMyId()
});

network.connect();
resizeCanvas(dom.canvas);
requestAnimationFrame(loop);

function applySnapshot(data) {
  for (const player of data.players) {
    if (player.id === network.getMyId()) {
      reconcilePlayer(localPlayer, player, pendingInputs);
    }
  }

  snapshotBuffer.push(data);
  renderScoreboard(dom.scoreboardEl, data.players, network.getMyId());
}

function updateLocalInput(dt) {
  if (!localPlayer.current) return;

  const currentInput = input.collectInput();
  predictPlayer(localPlayer.current, currentInput, dt);

  if (!network.getRoom()) return;

  inputSeq += 1;
  network.sendInput(inputSeq, currentInput);
  pendingInputs.push({ seq: inputSeq, input: currentInput, dt });
}

function shoot() {
  if (!localPlayer.current || !network.getRoom()) return;

  const now = performance.now();
  if (now < nextShootAt || localPlayer.current.respawning) return;
  nextShootAt = now + projectileConfig.shootCooldownMs;

  const shotId = `${network.getMyId()}:${++shotSeq}`;
  pendingShots.set(shotId, now);
  predictedProjectiles.set(
    shotId,
    createPredictedProjectile({
      shotId,
      ownerId: network.getMyId(),
      player: localPlayer.current,
      now
    })
  );
  network.sendShoot(shotId);
}

function handleShootAck(data) {
  const startedAt = pendingShots.get(data.shotId);
  if (!startedAt) return;

  const now = performance.now();
  pendingShots.delete(data.shotId);
  showShotPing(dom.shotPingEl, now - startedAt);
  predictedProjectiles.delete(data.shotId);
}

function loop(now) {
  const dt = Math.min(0.05, (now - lastFrame) / 1000);
  lastFrame = now;

  updateLocalInput(dt);
  renderer.draw(now, snapshotBuffer.sample(now));
  requestAnimationFrame(loop);
}
