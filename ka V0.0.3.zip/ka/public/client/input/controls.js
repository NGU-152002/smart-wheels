export function createInputController({
  canvas,
  fullscreenButton,
  joystickEl,
  joystickKnobEl,
  boostButton,
  shootButton,
  onResize,
  onShoot,
  onStatus
}) {
  const keys = new Set();
  const touchInput = {
    up: false,
    down: false,
    left: false,
    right: false,
    boost: false
  };

  let activeJoystickPointerId = null;

  window.addEventListener("resize", onResize);
  document.addEventListener("fullscreenchange", () => {
    fullscreenButton.textContent = document.fullscreenElement ? "Fullscreen on" : "Full screen";
    onResize();
  });

  window.addEventListener("keydown", event => {
    if (["ArrowUp", "ArrowDown", "ArrowLeft", "ArrowRight", " ", "Shift"].includes(event.key)) {
      event.preventDefault();
    }
    keys.add(event.key.toLowerCase());
  });
  window.addEventListener("keyup", event => keys.delete(event.key.toLowerCase()));
  window.addEventListener("blur", () => {
    keys.clear();
    resetJoystick();
    touchInput.boost = false;
  });

  canvas.addEventListener("pointerdown", event => {
    if (event.pointerType === "touch") {
      maybeStartFloatingJoystick(event);
      return;
    }

    onShoot();
  });
  canvas.addEventListener("pointermove", event => {
    if (event.pointerId === activeJoystickPointerId) updateJoystick(event);
  });

  for (const eventName of ["pointerup", "pointercancel", "lostpointercapture"]) {
    canvas.addEventListener(eventName, event => {
      if (event.pointerId === activeJoystickPointerId || eventName === "lostpointercapture") {
        activeJoystickPointerId = null;
        resetJoystick();
      }
    });
  }

  window.addEventListener("keydown", event => {
    if (event.code === "Space") onShoot();
  });
  fullscreenButton.addEventListener("click", enterFullscreen);
  shootButton.addEventListener("pointerdown", event => {
    event.preventDefault();
    onShoot();
  });

  bindHoldButton(boostButton, isPressed => {
    touchInput.boost = isPressed;
  });
  bindJoystick();

  function collectInput() {
    return {
      up: false,
      down: keys.has("s") || keys.has("arrowdown") || touchInput.down,
      left: keys.has("a") || keys.has("arrowleft") || touchInput.left,
      right: keys.has("d") || keys.has("arrowright") || touchInput.right,
      boost: keys.has("shift") || touchInput.boost
    };
  }

  async function enterFullscreen() {
    const target = document.documentElement;

    try {
      if (!document.fullscreenElement && target.requestFullscreen) {
        await target.requestFullscreen({ navigationUI: "hide" });
      }
      if (screen.orientation?.lock) {
        await screen.orientation.lock("landscape").catch(() => {});
      }
      fullscreenButton.textContent = "Fullscreen on";
    } catch {
      onStatus("Fullscreen not available");
    }

    onResize();
  }

  function bindHoldButton(button, onChange) {
    button.addEventListener("pointerdown", event => {
      event.preventDefault();
      button.setPointerCapture(event.pointerId);
      onChange(true);
    });

    for (const eventName of ["pointerup", "pointercancel", "lostpointercapture"]) {
      button.addEventListener(eventName, () => onChange(false));
    }
  }

  function bindJoystick() {
    joystickEl.addEventListener("pointerdown", event => {
      event.preventDefault();
      activeJoystickPointerId = event.pointerId;
      joystickEl.setPointerCapture(activeJoystickPointerId);
      placeFloatingJoystick(event.clientX, event.clientY);
      updateJoystick(event);
    });

    joystickEl.addEventListener("pointermove", event => {
      if (event.pointerId === activeJoystickPointerId) updateJoystick(event);
    });

    for (const eventName of ["pointerup", "pointercancel", "lostpointercapture"]) {
      joystickEl.addEventListener(eventName, event => {
        if (event.pointerId === activeJoystickPointerId || eventName === "lostpointercapture") {
          activeJoystickPointerId = null;
          resetJoystick();
        }
      });
    }
  }

  function maybeStartFloatingJoystick(event) {
    const rect = canvas.getBoundingClientRect();
    const isLeftSide = event.clientX < rect.left + rect.width * 0.55;

    if (!isLeftSide || activeJoystickPointerId !== null) return;

    event.preventDefault();
    activeJoystickPointerId = event.pointerId;
    canvas.setPointerCapture(activeJoystickPointerId);
    placeFloatingJoystick(event.clientX, event.clientY);
    updateJoystick(event);
  }

  function placeFloatingJoystick(clientX, clientY) {
    joystickEl.classList.add("floating");
    joystickEl.style.left = `${clientX}px`;
    joystickEl.style.top = `${clientY}px`;
  }

  function updateJoystick(event) {
    const rect = joystickEl.getBoundingClientRect();
    const radius = rect.width / 2;
    const maxDistance = radius - 28;
    const centerX = rect.left + radius;
    const centerY = rect.top + radius;
    const dx = event.clientX - centerX;
    const dy = event.clientY - centerY;
    const distance = Math.min(maxDistance, Math.hypot(dx, dy));
    const angle = Math.atan2(dy, dx);
    const knobX = Math.cos(angle) * distance;
    const knobY = Math.sin(angle) * distance;

    joystickKnobEl.style.transform = `translate(calc(-50% + ${knobX}px), calc(-50% + ${knobY}px))`;

    const threshold = 18;
    touchInput.up = dy < -threshold;
    touchInput.down = dy > threshold;
    touchInput.left = dx < -threshold;
    touchInput.right = dx > threshold;
  }

  function resetJoystick() {
    touchInput.up = false;
    touchInput.down = false;
    touchInput.left = false;
    touchInput.right = false;
    joystickKnobEl.style.transform = "translate(-50%, -50%)";
  }

  return { collectInput };
}
