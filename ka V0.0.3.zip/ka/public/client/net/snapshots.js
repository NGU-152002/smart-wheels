import { interpolationConfig } from "../config.js";
import { clamp, lerp, lerpAngle } from "../utils/math.js";

export function snapshotFromState(state, world) {
  if (state.world) {
    world.width = state.world.width;
    world.height = state.world.height;
  }

  return {
    time: Date.now(),
    players: Array.from(state.players?.values() || []).map(player => ({
      id: player.id,
      name: player.name,
      x: player.x,
      y: player.y,
      angle: player.angle,
      vx: player.vx,
      vy: player.vy,
      hp: player.hp,
      score: player.score,
      color: player.color,
      lastProcessedInput: player.lastProcessedInput,
      respawning: player.respawning,
      turning: player.turning || 0
    })),
    projectiles: Array.from(state.projectiles?.values() || []).map(projectile => ({
      id: projectile.id,
      ownerId: projectile.ownerId,
      x: projectile.x,
      y: projectile.y,
      vx: projectile.vx,
      vy: projectile.vy
    })),
    supplyBoxes: Array.from(state.supplyBoxes?.values() || []).map(supplyBox => ({
      id: supplyBox.id,
      x: supplyBox.x,
      y: supplyBox.y,
      active: supplyBox.active
    }))
  };
}

export function createSnapshotBuffer() {
  const snapshots = [];
  let serverTimeOffset = 0;

  function push(data) {
    const now = performance.now();
    const measuredOffset = data.time - now;
    serverTimeOffset = serverTimeOffset === 0 ? measuredOffset : lerp(serverTimeOffset, measuredOffset, 0.08);

    snapshots.push({
      time: data.time,
      players: data.players,
      projectiles: data.projectiles,
      supplyBoxes: data.supplyBoxes
    });

    const minimumTime = data.time - interpolationConfig.historyMs;
    while (snapshots.length > 2 && snapshots[0].time < minimumTime) {
      snapshots.shift();
    }
  }

  function sample(now) {
    return sampleSnapshot(snapshots, now + serverTimeOffset - interpolationConfig.delayMs);
  }

  return { push, sample };
}

function sampleSnapshot(snapshots, renderTime) {
  if (snapshots.length === 0) {
    return { players: [], projectiles: [], supplyBoxes: [] };
  }

  if (snapshots.length === 1 || renderTime <= snapshots[0].time) {
    return snapshots[0];
  }

  let older = snapshots[0];
  let newer = snapshots[snapshots.length - 1];

  for (let i = 0; i < snapshots.length - 1; i += 1) {
    if (snapshots[i].time <= renderTime && snapshots[i + 1].time >= renderTime) {
      older = snapshots[i];
      newer = snapshots[i + 1];
      break;
    }
  }

  if (renderTime >= newer.time) {
    return extrapolateSnapshot(newer, (renderTime - newer.time) / 1000);
  }

  const span = Math.max(1, newer.time - older.time);
  const t = clamp((renderTime - older.time) / span, 0, 1);

  return {
    time: renderTime,
    players: interpolateEntities(older.players, newer.players, t, interpolatePlayer),
    projectiles: interpolateEntities(older.projectiles, newer.projectiles, t, interpolateProjectile),
    supplyBoxes: newer.supplyBoxes || []
  };
}

function extrapolateSnapshot(snapshot, dt) {
  const cappedDt = Math.min(dt, 0.08);

  return {
    time: snapshot.time + cappedDt * 1000,
    supplyBoxes: snapshot.supplyBoxes || [],
    players: snapshot.players.map(player => ({
      ...player,
      x: player.x + (player.vx || 0) * cappedDt,
      y: player.y + (player.vy || 0) * cappedDt
    })),
    projectiles: snapshot.projectiles.map(projectile => ({
      ...projectile,
      x: projectile.x + (projectile.vx || 0) * cappedDt,
      y: projectile.y + (projectile.vy || 0) * cappedDt
    }))
  };
}

function interpolateEntities(olderEntities, newerEntities, t, interpolateOne) {
  const olderById = new Map(olderEntities.map(entity => [entity.id, entity]));

  return newerEntities.map(newer => {
    const older = olderById.get(newer.id);
    return older ? interpolateOne(older, newer, t) : newer;
  });
}

function interpolatePlayer(older, newer, t) {
  return {
    ...newer,
    x: lerp(older.x, newer.x, t),
    y: lerp(older.y, newer.y, t),
    angle: lerpAngle(older.angle, newer.angle, t),
    hp: Math.round(lerp(older.hp, newer.hp, t))
  };
}

function interpolateProjectile(older, newer, t) {
  return {
    ...newer,
    x: lerp(older.x, newer.x, t),
    y: lerp(older.y, newer.y, t)
  };
}
