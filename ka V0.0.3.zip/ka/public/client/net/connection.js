import { snapshotFromState } from "./snapshots.js";

export function createNetworkClient({
  world,
  onConnected,
  onDisconnected,
  onSnapshot,
  onNotice,
  onNetworkPing,
  onShootAck
}) {
  let room = null;
  let myId = null;
  let pingIntervalId = null;
  const guestId = getGuestId();

  function connect() {
    const client = new window.Colyseus.Client(`${location.protocol}//${location.host}`);

    client
      .joinOrCreate("kart_arena", { guestId })
      .then(joinedRoom => {
        room = joinedRoom;
        myId = room.sessionId;
        onConnected(myId);

        room.onMessage("welcome", data => {
          myId = data.id;
          Object.assign(world, data.world);
          onConnected(myId);
        });

        room.onMessage("notice", onNotice);
        room.onMessage("shoot_ack", onShootAck);
        room.onMessage("pong", data => {
          onNetworkPing(Math.max(0, Math.round(performance.now() - data.sentAt)));
        });
        room.onStateChange(state => onSnapshot(snapshotFromState(state, world)));
        startPingLoop();

        if (room.state) {
          onSnapshot(snapshotFromState(room.state, world));
        }

        room.onLeave(() => {
          room = null;
          stopPingLoop();
          onDisconnected();
          setTimeout(connect, 800);
        });
      })
      .catch(() => {
        room = null;
        stopPingLoop();
        onDisconnected(true);
        setTimeout(connect, 1200);
      });
  }

  function sendInput(seq, input) {
    room?.send("input", { seq, input });
  }

  function sendShoot(shotId) {
    room?.send("shoot", { shotId });
  }

  function getRoom() {
    return room;
  }

  function getMyId() {
    return myId;
  }

  function startPingLoop() {
    stopPingLoop();
    sendPing();
    pingIntervalId = setInterval(sendPing, 1000);
  }

  function stopPingLoop() {
    if (pingIntervalId) {
      clearInterval(pingIntervalId);
      pingIntervalId = null;
    }
  }

  function sendPing() {
    if (room) {
      room.send("ping", { sentAt: performance.now() });
    }
  }

  return { connect, getRoom, getMyId, sendInput, sendShoot };
}

function getGuestId() {
  const storageKey = "kart_guest_id";
  const storage = getLocalStorage();
  const existing = storage?.getItem(storageKey);
  if (existing) return existing;

  const id = `guest_${createRandomId()}`;
  storage?.setItem(storageKey, id);
  return id;
}

function createRandomId() {
  if (globalThis.crypto?.randomUUID) {
    return globalThis.crypto.randomUUID().replaceAll("-", "");
  }

  return `${Date.now().toString(36)}${Math.random().toString(36).slice(2)}`;
}

function getLocalStorage() {
  try {
    return globalThis.localStorage;
  } catch {
    return null;
  }
}
