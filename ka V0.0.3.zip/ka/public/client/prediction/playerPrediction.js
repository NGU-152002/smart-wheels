import { kartConfig, world } from "../config.js";
import { clamp } from "../utils/math.js";

export function predictPlayer(player, input, dt) {
  player.turning = (input.right ? 1 : 0) - (input.left ? 1 : 0);
  if (input.left) player.angle -= kartConfig.turnSpeed * dt;
  if (input.right) player.angle += kartConfig.turnSpeed * dt;

  const thrust = input.boost ? kartConfig.boostThrust : kartConfig.thrust;
  if (input.down) {
    player.vx -= Math.cos(player.angle) * kartConfig.reverseThrust * dt;
    player.vy -= Math.sin(player.angle) * kartConfig.reverseThrust * dt;
  } else {
    player.vx += Math.cos(player.angle) * thrust * dt;
    player.vy += Math.sin(player.angle) * thrust * dt;
  }

  const maxSpeed = input.boost ? kartConfig.boostMaxSpeed : kartConfig.maxSpeed;
  const speed = Math.hypot(player.vx, player.vy);
  if (speed > maxSpeed) {
    player.vx = (player.vx / speed) * maxSpeed;
    player.vy = (player.vy / speed) * maxSpeed;
  }

  player.vx *= kartConfig.friction;
  player.vy *= kartConfig.friction;
  player.x = clamp(player.x + player.vx * dt, kartConfig.boundsRadius, world.width - kartConfig.boundsRadius);
  player.y = clamp(player.y + player.vy * dt, kartConfig.boundsRadius, world.height - kartConfig.boundsRadius);
}

export function reconcilePlayer(localPlayer, serverPlayer, pendingInputs) {
  if (!localPlayer.current) {
    localPlayer.current = { ...serverPlayer };
    return;
  }

  Object.assign(localPlayer.current, serverPlayer);

  while (pendingInputs.length && pendingInputs[0].seq <= serverPlayer.lastProcessedInput) {
    pendingInputs.shift();
  }

  for (const pending of pendingInputs) {
    predictPlayer(localPlayer.current, pending.input, pending.dt);
  }
}
