import { projectileConfig } from "../config.js";

export function createPredictedProjectile({ shotId, ownerId, player, now }) {
  const angle = player.angle;

  return {
    id: shotId,
    ownerId,
    x: player.x + Math.cos(angle) * projectileConfig.spawnOffset,
    y: player.y + Math.sin(angle) * projectileConfig.spawnOffset,
    vx: Math.cos(angle) * projectileConfig.speed + player.vx * projectileConfig.inheritedVelocityScale,
    vy: Math.sin(angle) * projectileConfig.speed + player.vy * projectileConfig.inheritedVelocityScale,
    predicted: true,
    startedAt: now,
    expiresAt: now + projectileConfig.predictionLifetimeMs
  };
}

export function predictedProjectile(projectile, now) {
  const elapsed = (now - projectile.startedAt) / 1000;

  return {
    ...projectile,
    x: projectile.x + projectile.vx * elapsed,
    y: projectile.y + projectile.vy * elapsed
  };
}
