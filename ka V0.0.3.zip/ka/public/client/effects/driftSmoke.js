import { renderConfig } from "../config.js";

export function createDriftSmoke() {
  const particles = [];

  function update(players, now) {
    for (const player of players || []) {
      if (player.respawning) continue;

      const speed = Math.hypot(player.vx || 0, player.vy || 0);
      const isTurning = Math.abs(player.turning || 0) > 0.5;
      if (!isTurning || speed < 170) continue;

      const lastSmokeAt = player.lastSmokeAt || 0;
      if (now - lastSmokeAt < 34) continue;
      player.lastSmokeAt = now;

      const rearX = player.x - Math.cos(player.angle) * 30;
      const rearY = player.y - Math.sin(player.angle) * 30;
      const side = player.turning > 0 ? -1 : 1;
      const sideX = Math.cos(player.angle + Math.PI / 2) * side * 14;
      const sideY = Math.sin(player.angle + Math.PI / 2) * side * 14;

      for (let i = 0; i < 2; i += 1) {
        particles.push({
          x: rearX + sideX + (Math.random() - 0.5) * 14,
          y: rearY + sideY + (Math.random() - 0.5) * 14,
          vx: -Math.cos(player.angle) * 34 + (Math.random() - 0.5) * 26,
          vy: -Math.sin(player.angle) * 34 + (Math.random() - 0.5) * 26,
          rotation: Math.random() * Math.PI * 2,
          spin: (Math.random() - 0.5) * 1.5,
          size: renderConfig.driftSmokeSize * (0.9 + Math.random() * 0.65),
          bornAt: now,
          life: 500
        });
      }
    }

    while (particles.length > 320) {
      particles.shift();
    }
  }

  function draw(ctx, now, driftSmokeSprite) {
    for (let i = particles.length - 1; i >= 0; i -= 1) {
      const particle = particles[i];
      const age = now - particle.bornAt;
      if (age >= particle.life) {
        particles.splice(i, 1);
        continue;
      }

      const t = age / particle.life;
      const dt = 1 / 60;
      particle.x += particle.vx * dt;
      particle.y += particle.vy * dt;
      particle.rotation += particle.spin * dt;

      const alpha = (1 - t) * 0.62;
      const size = particle.size * (0.75 + t * 0.85);

      ctx.save();
      ctx.globalAlpha = alpha;
      ctx.translate(particle.x, particle.y);
      ctx.rotate(particle.rotation);

      if (driftSmokeSprite.ready) {
        ctx.drawImage(driftSmokeSprite.image, -size / 2, -size / 2, size, size);
      } else {
        ctx.fillStyle = "rgba(220, 226, 220, 0.7)";
        ctx.beginPath();
        ctx.arc(0, 0, size / 2, 0, Math.PI * 2);
        ctx.fill();
      }

      ctx.restore();
    }
  }

  return { update, draw };
}
