import { kartConfig, renderConfig, world } from "../config.js";
import { clamp, roundRect } from "../utils/math.js";
import { predictedProjectile } from "../prediction/projectiles.js";

export function createRenderer({ canvas, ctx, assets, driftSmoke, predictedProjectiles, getLocalPlayer, getMyId }) {
  const camera = { x: 0, y: 0 };

  function draw(now, remoteFrame) {
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    ctx.save();
    ctx.scale(devicePixelRatio, devicePixelRatio);

    const viewWidth = canvas.width / devicePixelRatio / renderConfig.cameraZoom;
    const viewHeight = canvas.height / devicePixelRatio / renderConfig.cameraZoom;
    const localPlayer = getLocalPlayer();
    const myId = getMyId();
    const focus = localPlayer || { x: world.width / 2, y: world.height / 2 };

    camera.x += (focus.x - viewWidth / 2 - camera.x) * 0.12;
    camera.y += (focus.y - viewHeight / 2 - camera.y) * 0.12;
    camera.x = clamp(camera.x, 0, Math.max(0, world.width - viewWidth));
    camera.y = clamp(camera.y, 0, Math.max(0, world.height - viewHeight));

    ctx.scale(renderConfig.cameraZoom, renderConfig.cameraZoom);
    ctx.translate(-camera.x, -camera.y);
    drawArena();

    driftSmoke.update(
      localPlayer ? [...remoteFrame.players.filter(player => player.id !== myId), localPlayer] : remoteFrame.players,
      now
    );
    driftSmoke.draw(ctx, now, assets.driftSmokeSprite);
    drawSupplyBoxes(remoteFrame.supplyBoxes, now);

    const renderedProjectileIds = new Set();
    for (const projectile of remoteFrame.projectiles) {
      if (predictedProjectiles.has(projectile.id)) continue;
      renderedProjectileIds.add(projectile.id);
      drawProjectile(projectile);
    }

    for (const projectile of predictedProjectiles.values()) {
      if (renderedProjectileIds.has(projectile.id) || now > projectile.expiresAt) {
        predictedProjectiles.delete(projectile.id);
        continue;
      }
      drawProjectile(predictedProjectile(projectile, now));
    }

    for (const player of remoteFrame.players) {
      if (player.id !== myId) drawKart(player, false);
    }

    if (localPlayer) drawKart(localPlayer, true);

    drawMinimap(viewWidth, remoteFrame.players, localPlayer, myId);
    ctx.restore();
  }

  function drawArena() {
    ctx.fillStyle = "#2a3431";
    ctx.fillRect(0, 0, world.width, world.height);

    ctx.strokeStyle = "rgba(255,255,255,0.08)";
    ctx.lineWidth = 2;
    for (let x = 0; x <= world.width; x += 80) {
      ctx.beginPath();
      ctx.moveTo(x, 0);
      ctx.lineTo(x, world.height);
      ctx.stroke();
    }
    for (let y = 0; y <= world.height; y += 80) {
      ctx.beginPath();
      ctx.moveTo(0, y);
      ctx.lineTo(world.width, y);
      ctx.stroke();
    }

    ctx.strokeStyle = "#d9b64f";
    ctx.lineWidth = 8;
    ctx.strokeRect(18, 18, world.width - 36, world.height - 36);

    ctx.fillStyle = "rgba(255,255,255,0.08)";
    for (const obstacle of [
      [360, 250, 180, 56],
      [980, 210, 240, 56],
      [690, 560, 220, 56],
      [260, 710, 170, 56],
      [1160, 720, 170, 56]
    ]) {
      roundRect(ctx, ...obstacle, 8);
      ctx.fill();
    }
  }

  function drawKart(player, isLocal) {
    if (assets.kartSprite.ready) {
      drawKartSprite(player, isLocal);
    } else {
      drawFallbackKart(player, isLocal);
    }

    drawPlayerHud(player);
  }

  function drawKartSprite(player, isLocal) {
    ctx.save();
    ctx.translate(player.x, player.y);
    ctx.rotate(player.angle - Math.PI / 2);

    if (player.respawning) {
      ctx.globalAlpha = 0.38;
    }

    ctx.shadowColor = isLocal ? "rgba(255, 255, 255, 0.45)" : player.color;
    ctx.shadowBlur = isLocal ? 14 : 8;
    ctx.drawImage(
      assets.kartSprite.image,
      -kartConfig.spriteSize / 2,
      -kartConfig.spriteSize / 2,
      kartConfig.spriteSize,
      kartConfig.spriteSize
    );
    ctx.restore();

    ctx.save();
    ctx.strokeStyle = isLocal ? "#ffffff" : player.color;
    ctx.lineWidth = isLocal ? 3 : 2;
    ctx.globalAlpha = isLocal ? 0.9 : 0.65;
    ctx.beginPath();
    ctx.arc(player.x, player.y, 29, 0, Math.PI * 2);
    ctx.stroke();
    ctx.restore();
  }

  function drawFallbackKart(player, isLocal) {
    ctx.save();
    ctx.translate(player.x, player.y);
    ctx.rotate(player.angle);

    ctx.fillStyle = player.respawning ? "rgba(255,255,255,0.28)" : player.color;
    roundRect(ctx, -25, -16, 50, 32, 7);
    ctx.fill();

    ctx.fillStyle = "#111";
    ctx.fillRect(-14, -22, 11, 8);
    ctx.fillRect(-14, 14, 11, 8);
    ctx.fillRect(8, -22, 11, 8);
    ctx.fillRect(8, 14, 11, 8);

    ctx.fillStyle = isLocal ? "#ffffff" : "#18201f";
    ctx.beginPath();
    ctx.moveTo(28, 0);
    ctx.lineTo(10, -9);
    ctx.lineTo(10, 9);
    ctx.closePath();
    ctx.fill();
    ctx.restore();
  }

  function drawPlayerHud(player) {
    ctx.fillStyle = "#f7fbfa";
    ctx.font = "13px system-ui";
    ctx.textAlign = "center";
    ctx.fillText(player.name || "P", player.x, player.y - 42);

    ctx.fillStyle = "rgba(0,0,0,0.45)";
    roundRect(ctx, player.x - 28, player.y + 36, 56, 7, 4);
    ctx.fill();
    ctx.fillStyle = player.hp > 35 ? "#64d46f" : "#ff5d5d";
    roundRect(ctx, player.x - 28, player.y + 36, 56 * clamp(player.hp / 100, 0, 1), 7, 4);
    ctx.fill();
  }

  function drawProjectile(projectile) {
    ctx.fillStyle = "#ffef82";
    ctx.beginPath();
    ctx.arc(projectile.x, projectile.y, 6, 0, Math.PI * 2);
    ctx.fill();

    ctx.strokeStyle = "rgba(255,239,130,0.4)";
    ctx.lineWidth = 3;
    ctx.beginPath();
    ctx.arc(projectile.x, projectile.y, 12, 0, Math.PI * 2);
    ctx.stroke();
  }

  function drawSupplyBoxes(supplyBoxes, now) {
    for (const supplyBox of supplyBoxes || []) {
      if (!supplyBox.active) continue;

      const phase = now / 650 + Number(supplyBox.id) * 0.85;
      const bob = Math.sin(phase);
      const yOffset = bob * 8;
      const downwardAmount = (bob + 1) / 2;
      const scale = 1 - downwardAmount * 0.18;
      const size = renderConfig.supplyBoxSize * scale;
      const ringRadius = 28 * scale;

      ctx.save();
      ctx.translate(supplyBox.x, supplyBox.y + yOffset);
      ctx.shadowColor = "rgba(106, 255, 141, 0.42)";
      ctx.shadowBlur = 12 + (1 - downwardAmount) * 6;

      if (assets.supplyBoxSprite.ready) {
        ctx.drawImage(assets.supplyBoxSprite.image, -size / 2, -size / 2, size, size);
      } else {
        ctx.fillStyle = "#46d86f";
        roundRect(ctx, -18 * scale, -18 * scale, 36 * scale, 36 * scale, 7 * scale);
        ctx.fill();
        ctx.fillStyle = "#f7fbfa";
        ctx.fillRect(-4 * scale, -13 * scale, 8 * scale, 26 * scale);
        ctx.fillRect(-13 * scale, -4 * scale, 26 * scale, 8 * scale);
      }

      ctx.restore();

      ctx.save();
      ctx.strokeStyle = `rgba(116, 255, 154, ${0.42 + (1 - downwardAmount) * 0.24})`;
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.arc(supplyBox.x, supplyBox.y + yOffset, ringRadius, 0, Math.PI * 2);
      ctx.stroke();
      ctx.restore();
    }
  }

  function drawMinimap(viewWidth, players, localPlayer, myId) {
    const mapWidth = 170;
    const mapHeight = Math.round((world.height / world.width) * mapWidth);
    const padding = 14;
    const x = camera.x + viewWidth - mapWidth - padding;
    const y = camera.y + padding;
    const scaleX = mapWidth / world.width;
    const scaleY = mapHeight / world.height;

    ctx.save();
    ctx.fillStyle = "rgba(7, 12, 12, 0.72)";
    ctx.strokeStyle = "rgba(255, 255, 255, 0.28)";
    ctx.lineWidth = 1;
    roundRect(ctx, x, y, mapWidth, mapHeight, 8);
    ctx.fill();
    ctx.stroke();

    ctx.strokeStyle = "rgba(255, 255, 255, 0.12)";
    ctx.strokeRect(x + 6, y + 6, mapWidth - 12, mapHeight - 12);

    for (const player of players) {
      if (player.id !== myId) drawMinimapDot(player, x, y, scaleX, scaleY, false);
    }

    if (localPlayer) {
      drawMinimapDot(localPlayer, x, y, scaleX, scaleY, true);
    }

    ctx.restore();
  }

  function drawMinimapDot(player, mapX, mapY, scaleX, scaleY, isLocal) {
    const dotX = mapX + player.x * scaleX;
    const dotY = mapY + player.y * scaleY;

    ctx.fillStyle = isLocal ? "#ffffff" : player.color;
    ctx.strokeStyle = isLocal ? "#1b2422" : "rgba(255, 255, 255, 0.85)";
    ctx.lineWidth = isLocal ? 2 : 1;
    ctx.beginPath();
    ctx.arc(dotX, dotY, isLocal ? 5 : 4, 0, Math.PI * 2);
    ctx.fill();
    ctx.stroke();
  }

  return { draw };
}
