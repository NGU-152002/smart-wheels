export const world = { width: 1600, height: 1000 };

export const interpolationConfig = {
  delayMs: 120,
  historyMs: 350
};

export const kartConfig = {
  spriteSize: 76,
  boundsRadius: 38,
  turnSpeed: 2.5,
  thrust: 520,
  boostThrust: 760,
  reverseThrust: 320,
  maxSpeed: 330,
  boostMaxSpeed: 430,
  friction: 0.985
};

export const projectileConfig = {
  shootCooldownMs: 280,
  spawnOffset: 34,
  speed: 680,
  inheritedVelocityScale: 0.3,
  predictionLifetimeMs: 700
};

export const renderConfig = {
  cameraZoom: 0.78,
  supplyBoxSize: 62,
  driftSmokeSize: 38
};
