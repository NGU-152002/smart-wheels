export function getDom() {
  const canvas = document.querySelector("#game");

  return {
    canvas,
    ctx: canvas.getContext("2d"),
    statusEl: document.querySelector("#status"),
    networkPingEl: document.querySelector("#networkPing"),
    shotPingEl: document.querySelector("#shotPing"),
    scoreboardEl: document.querySelector("#scoreboard"),
    fullscreenButton: document.querySelector("#fullscreenButton"),
    joystickEl: document.querySelector("#joystick"),
    joystickKnobEl: document.querySelector("#joystickKnob"),
    boostButton: document.querySelector("#boostButton"),
    shootButton: document.querySelector("#shootButton")
  };
}

export function resizeCanvas(canvas) {
  const rect = canvas.getBoundingClientRect();
  canvas.width = Math.floor(rect.width * devicePixelRatio);
  canvas.height = Math.floor(rect.height * devicePixelRatio);
}
