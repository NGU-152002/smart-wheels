export function loadGameAssets() {
  return {
    kartSprite: loadImage("/assets/kart-player.png"),
    supplyBoxSprite: loadImage("/assets/supply-box.png"),
    driftSmokeSprite: loadImage("/assets/drift-smoke.png")
  };
}

function loadImage(src) {
  const image = new Image();
  const asset = { image, ready: false };

  image.addEventListener("load", () => {
    asset.ready = true;
  });
  image.addEventListener("error", () => {
    asset.ready = false;
  });
  image.src = src;

  return asset;
}
