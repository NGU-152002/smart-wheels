export function setStatus(statusEl, text) {
  statusEl.textContent = text;
}

export function showNetworkPing(networkPingEl, rtt) {
  networkPingEl.textContent = `Ping: ${rtt} ms`;
}

export function clearNetworkPing(networkPingEl) {
  networkPingEl.textContent = "Ping: --";
}

export function showShotPing(shotPingEl, ms) {
  shotPingEl.textContent = `Shoot ping: ${Math.round(ms)} ms`;
}

export function renderScoreboard(scoreboardEl, players, myId) {
  scoreboardEl.innerHTML = players
    .sort((a, b) => b.score - a.score)
    .map(
      player => `
        <span class="player-chip">
          <span class="swatch" style="background:${player.color}"></span>
          ${player.name}${player.id === myId ? " (you)" : ""}: ${player.score} · ${player.hp}hp
        </span>
      `
    )
    .join("");
}
