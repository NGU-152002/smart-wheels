import os from "node:os";
import path from "node:path";
import { fileURLToPath } from "node:url";
import express from "express";
import { Server } from "colyseus";
import { networkConfig } from "./server/config/gameConfig.js";
import { closeMongo, connectMongo } from "./server/db/mongo.js";
import { createRedisBackends } from "./server/db/redis.js";
import { KartRoom } from "./server/rooms/KartRoom.js";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const publicDir = path.join(__dirname, "public");

let gameServer = null;

try {
  const redisUrl = requireEnv("REDIS_URL");
  const redisBackends = createRedisBackends(redisUrl);

  gameServer = new Server({
    driver: redisBackends.driver,
    presence: redisBackends.presence,
    express: app => {
      app.use(express.static(publicDir));
      app.get("/", (_req, res) => res.sendFile(path.join(publicDir, "index.html")));
    }
  });

  gameServer.define("kart_arena", KartRoom);

  await connectMongo();
  await gameServer.listen(networkConfig.port, networkConfig.host);

  console.log(`Prototype running locally at http://127.0.0.1:${networkConfig.port}`);

  for (const address of getLanAddresses()) {
    console.log(`LAN access: http://${address}:${networkConfig.port}`);
  }
} catch (error) {
  console.error(`Server startup failed: ${error.message}`);
  await closeMongo();
  process.exit(1);
}

process.once("SIGINT", shutdown);
process.once("SIGTERM", shutdown);

async function shutdown() {
  if (gameServer) {
    await gameServer.gracefullyShutdown();
  }
  await closeMongo();
  process.exit(0);
}

function requireEnv(name) {
  const value = process.env[name];
  if (!value) {
    throw new Error(`${name} is required`);
  }
  return value;
}

function getLanAddresses() {
  return Object.values(os.networkInterfaces())
    .flat()
    .filter(address => address && address.family === "IPv4" && !address.internal)
    .map(address => address.address);
}
