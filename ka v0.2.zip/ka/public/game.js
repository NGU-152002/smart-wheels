const canvas = document.querySelector("#game");
const ctx = canvas.getContext("2d");
const statusEl = document.querySelector("#status");
const networkPingEl = document.querySelector("#networkPing");
const shotPingEl = document.querySelector("#shotPing");
const scoreboardEl = document.querySelector("#scoreboard");
const fullscreenButton = document.querySelector("#fullscreenButton");
const joystickEl = document.querySelector("#joystick");
const joystickKnobEl = document.querySelector("#joystickKnob");
const boostButton = document.querySelector("#boostButton");
const shootButton = document.querySelector("#shootButton");

const world = { width: 1600, height: 1000 };
const INTERPOLATION_DELAY = 120;
const SNAPSHOT_HISTORY = 350;
const KART_SPRITE_SIZE = 76;
const PLAYER_BOUNDS_RADIUS = KART_SPRITE_SIZE / 2;
const SUPPLY_BOX_SIZE = 62;
const DRIFT_SMOKE_SIZE = 38;
const SHOOT_COOLDOWN_MS = 280;
const keys = new Set();
const pendingInputs = [];
const pendingShots = new Map();
const predictedProjectiles = new Map();
const driftSmokeParticles = [];
const snapshotBuffer = [];
const touchInput = {
  up: false,
  down: false,
  left: false,
  right: false,
  boost: false
};
const kartSprite = new Image();
kartSprite.src = "/assets/kart-player.png";
const supplyBoxSprite = new Image();
supplyBoxSprite.src = "/assets/supply-box.png";
const driftSmokeSprite = new Image();
driftSmokeSprite.src = "/assets/drift-smoke.png";

let kartSpriteReady = false;
let supplyBoxSpriteReady = false;
let driftSmokeSpriteReady = false;

let room;
let myId = null;
let inputSeq = 0;
let shotSeq = 0;
let nextShootAt = 0;
let mouse = { x: 0, y: 0 };
let localPlayer = null;
let camera = { x: 0, y: 0 };
let lastFrame = performance.now();
let serverTimeOffset = 0;
let activeJoystickPointerId = null;
let pingIntervalId = null;

kartSprite.addEventListener("load", () => {
  kartSpriteReady = true;
});
kartSprite.addEventListener("error", () => {
  kartSpriteReady = false;
});
supplyBoxSprite.addEventListener("load", () => {
  supplyBoxSpriteReady = true;
});
supplyBoxSprite.addEventListener("error", () => {
  supplyBoxSpriteReady = false;
});
driftSmokeSprite.addEventListener("load", () => {
  driftSmokeSpriteReady = true;
});
driftSmokeSprite.addEventListener("error", () => {
  driftSmokeSpriteReady = false;
});

connect();
resize();
requestAnimationFrame(loop);

window.addEventListener("resize", resize);
document.addEventListener("fullscreenchange", () => {
  fullscreenButton.textContent = document.fullscreenElement ? "Fullscreen on" : "Full screen";
  resize();
});
window.addEventListener("keydown", event => {
  if (["ArrowUp", "ArrowDown", "ArrowLeft", "ArrowRight", " ", "Shift"].includes(event.key)) {
    event.preventDefault();
  }
  keys.add(event.key.toLowerCase());
});
window.addEventListener("keyup", event => keys.delete(event.key.toLowerCase()));
window.addEventListener("blur", () => {
  keys.clear();
  resetJoystick();
  touchInput.boost = false;
});

canvas.addEventListener("mousemove", event => {
  const rect = canvas.getBoundingClientRect();
  mouse = {
    x: event.clientX - rect.left,
    y: event.clientY - rect.top
  };
});

canvas.addEventListener("pointerdown", event => {
  if (event.pointerType === "touch") {
    maybeStartFloatingJoystick(event);
    return;
  }

  shoot();
});
window.addEventListener("keydown", event => {
  if (event.code === "Space") shoot();
});
fullscreenButton.addEventListener("click", enterFullscreen);
shootButton.addEventListener("pointerdown", event => {
  event.preventDefault();
  shoot();
});
bindHoldButton(boostButton, isPressed => {
  touchInput.boost = isPressed;
});
bindJoystick();

function connect() {
  const client = new Colyseus.Client(`${location.protocol}//${location.host}`);

  client
    .joinOrCreate("kart_arena")
    .then(joinedRoom => {
      room = joinedRoom;
      myId = room.sessionId;
      statusEl.textContent = "Connected";

      room.onMessage("welcome", data => {
        myId = data.id;
        Object.assign(world, data.world);
      });

      room.onMessage("notice", text => {
        statusEl.textContent = text;
        setTimeout(() => {
          if (room) statusEl.textContent = "Connected";
        }, 1200);
      });

      room.onMessage("shoot_ack", showShotPing);
      room.onMessage("pong", showNetworkPing);
      room.onStateChange(state => applySnapshot(snapshotFromState(state)));
      startPingLoop();

      if (room.state) {
        applySnapshot(snapshotFromState(room.state));
      }

      room.onLeave(() => {
        room = null;
        stopPingLoop();
        networkPingEl.textContent = "Ping: --";
        statusEl.textContent = "Disconnected. Reconnecting...";
        setTimeout(connect, 800);
      });
    })
    .catch(() => {
      room = null;
      stopPingLoop();
      networkPingEl.textContent = "Ping: --";
      statusEl.textContent = "Connection failed. Reconnecting...";
      setTimeout(connect, 1200);
    });
}

function startPingLoop() {
  stopPingLoop();
  sendPing();
  pingIntervalId = setInterval(sendPing, 1000);
}

function stopPingLoop() {
  if (pingIntervalId) {
    clearInterval(pingIntervalId);
    pingIntervalId = null;
  }
}

function sendPing() {
  if (room) {
    room.send("ping", { sentAt: performance.now() });
  }
}

function showNetworkPing(data) {
  const rtt = Math.max(0, Math.round(performance.now() - data.sentAt));
  networkPingEl.textContent = `Ping: ${rtt} ms`;
}

function snapshotFromState(state) {
  if (state.world) {
    world.width = state.world.width;
    world.height = state.world.height;
  }

  return {
    time: Date.now(),
    players: Array.from(state.players?.values() || []).map(player => ({
      id: player.id,
      name: player.name,
      x: player.x,
      y: player.y,
      angle: player.angle,
      vx: player.vx,
      vy: player.vy,
      hp: player.hp,
      score: player.score,
      color: player.color,
      lastProcessedInput: player.lastProcessedInput,
      respawning: player.respawning,
      turning: player.turning || 0
    })),
    projectiles: Array.from(state.projectiles?.values() || []).map(projectile => ({
      id: projectile.id,
      ownerId: projectile.ownerId,
      x: projectile.x,
      y: projectile.y,
      vx: projectile.vx,
      vy: projectile.vy
    })),
    supplyBoxes: Array.from(state.supplyBoxes?.values() || []).map(supplyBox => ({
      id: supplyBox.id,
      x: supplyBox.x,
      y: supplyBox.y,
      active: supplyBox.active
    }))
  };
}

async function enterFullscreen() {
  const target = document.documentElement;

  try {
    if (!document.fullscreenElement && target.requestFullscreen) {
      await target.requestFullscreen({ navigationUI: "hide" });
    }
    if (screen.orientation?.lock) {
      await screen.orientation.lock("landscape").catch(() => {});
    }
    fullscreenButton.textContent = "Fullscreen on";
  } catch {
    statusEl.textContent = "Fullscreen not available";
  }

  resize();
}

function bindHoldButton(button, onChange) {
  button.addEventListener("pointerdown", event => {
    event.preventDefault();
    button.setPointerCapture(event.pointerId);
    onChange(true);
  });

  for (const eventName of ["pointerup", "pointercancel", "lostpointercapture"]) {
    button.addEventListener(eventName, () => onChange(false));
  }
}

function bindJoystick() {
  joystickEl.addEventListener("pointerdown", event => {
    event.preventDefault();
    activeJoystickPointerId = event.pointerId;
    joystickEl.setPointerCapture(activeJoystickPointerId);
    placeFloatingJoystick(event.clientX, event.clientY);
    updateJoystick(event);
  });

  joystickEl.addEventListener("pointermove", event => {
    if (event.pointerId === activeJoystickPointerId) updateJoystick(event);
  });

  for (const eventName of ["pointerup", "pointercancel", "lostpointercapture"]) {
    joystickEl.addEventListener(eventName, event => {
      if (event.pointerId === activeJoystickPointerId || eventName === "lostpointercapture") {
        activeJoystickPointerId = null;
        resetJoystick();
      }
    });
  }
}

function maybeStartFloatingJoystick(event) {
  const rect = canvas.getBoundingClientRect();
  const isLeftSide = event.clientX < rect.left + rect.width * 0.55;

  if (!isLeftSide || activeJoystickPointerId !== null) return;

  event.preventDefault();
  activeJoystickPointerId = event.pointerId;
  canvas.setPointerCapture(activeJoystickPointerId);
  placeFloatingJoystick(event.clientX, event.clientY);
  updateJoystick(event);
}

canvas.addEventListener("pointermove", event => {
  if (event.pointerId === activeJoystickPointerId) updateJoystick(event);
});

for (const eventName of ["pointerup", "pointercancel", "lostpointercapture"]) {
  canvas.addEventListener(eventName, event => {
    if (event.pointerId === activeJoystickPointerId || eventName === "lostpointercapture") {
      activeJoystickPointerId = null;
      resetJoystick();
    }
  });
}

function placeFloatingJoystick(clientX, clientY) {
  joystickEl.classList.add("floating");
  joystickEl.style.left = `${clientX}px`;
  joystickEl.style.top = `${clientY}px`;
}

function updateJoystick(event) {
  const rect = joystickEl.getBoundingClientRect();
  const radius = rect.width / 2;
  const maxDistance = radius - 28;
  const centerX = rect.left + radius;
  const centerY = rect.top + radius;
  const dx = event.clientX - centerX;
  const dy = event.clientY - centerY;
  const distance = Math.min(maxDistance, Math.hypot(dx, dy));
  const angle = Math.atan2(dy, dx);
  const knobX = Math.cos(angle) * distance;
  const knobY = Math.sin(angle) * distance;

  joystickKnobEl.style.transform = `translate(calc(-50% + ${knobX}px), calc(-50% + ${knobY}px))`;

  const threshold = 18;
  touchInput.up = dy < -threshold;
  touchInput.down = dy > threshold;
  touchInput.left = dx < -threshold;
  touchInput.right = dx > threshold;
}

function resetJoystick() {
  touchInput.up = false;
  touchInput.down = false;
  touchInput.left = false;
  touchInput.right = false;
  joystickKnobEl.style.transform = "translate(-50%, -50%)";
}

function applySnapshot(data) {
  const now = performance.now();
  const measuredOffset = data.time - now;
  serverTimeOffset = serverTimeOffset === 0 ? measuredOffset : lerp(serverTimeOffset, measuredOffset, 0.08);

  for (const player of data.players) {
    if (player.id === myId) {
      reconcile(player);
    }
  }

  snapshotBuffer.push({
    time: data.time,
    players: data.players,
    projectiles: data.projectiles,
    supplyBoxes: data.supplyBoxes
  });

  const minimumTime = data.time - SNAPSHOT_HISTORY;
  while (snapshotBuffer.length > 2 && snapshotBuffer[0].time < minimumTime) {
    snapshotBuffer.shift();
  }

  renderScoreboard(data.players);
}

function reconcile(serverPlayer) {
  if (!localPlayer) {
    localPlayer = { ...serverPlayer };
    return;
  }

  Object.assign(localPlayer, serverPlayer);

  while (pendingInputs.length && pendingInputs[0].seq <= serverPlayer.lastProcessedInput) {
    pendingInputs.shift();
  }

  for (const pending of pendingInputs) {
    predict(localPlayer, pending.input, pending.dt);
  }
}

function collectInput() {
  return {
    up: false,
    down: keys.has("s") || keys.has("arrowdown") || touchInput.down,
    left: keys.has("a") || keys.has("arrowleft") || touchInput.left,
    right: keys.has("d") || keys.has("arrowright") || touchInput.right,
    boost: keys.has("shift") || touchInput.boost
  };
}

function updateLocalInput(dt) {
  if (!localPlayer) return;

  const input = collectInput();

  predict(localPlayer, input, dt);

  if (!room) return;

  inputSeq += 1;

  room.send("input", { seq: inputSeq, input });
  pendingInputs.push({ seq: inputSeq, input, dt });
}

function predict(player, input, dt) {
  const turnSpeed = 2.5;
  player.turning = (input.right ? 1 : 0) - (input.left ? 1 : 0);
  if (input.left) player.angle -= turnSpeed * dt;
  if (input.right) player.angle += turnSpeed * dt;

  const thrust = input.boost ? 760 : 520;
  const reverse = 320;
  if (input.down) {
    player.vx -= Math.cos(player.angle) * reverse * dt;
    player.vy -= Math.sin(player.angle) * reverse * dt;
  } else {
    player.vx += Math.cos(player.angle) * thrust * dt;
    player.vy += Math.sin(player.angle) * thrust * dt;
  }

  const maxSpeed = input.boost ? 430 : 330;
  const speed = Math.hypot(player.vx, player.vy);
  if (speed > maxSpeed) {
    player.vx = (player.vx / speed) * maxSpeed;
    player.vy = (player.vy / speed) * maxSpeed;
  }

  player.vx *= 0.985;
  player.vy *= 0.985;
  player.x = clamp(player.x + player.vx * dt, PLAYER_BOUNDS_RADIUS, world.width - PLAYER_BOUNDS_RADIUS);
  player.y = clamp(player.y + player.vy * dt, PLAYER_BOUNDS_RADIUS, world.height - PLAYER_BOUNDS_RADIUS);
}

function shoot() {
  if (!localPlayer || !room) return;

  const now = performance.now();
  if (now < nextShootAt || localPlayer.respawning) return;
  nextShootAt = now + SHOOT_COOLDOWN_MS;

  const shotId = `${myId}:${++shotSeq}`;
  const angle = localPlayer.angle;
  const predicted = {
    id: shotId,
    ownerId: myId,
    x: localPlayer.x + Math.cos(angle) * 34,
    y: localPlayer.y + Math.sin(angle) * 34,
    vx: Math.cos(angle) * 680 + localPlayer.vx * 0.3,
    vy: Math.sin(angle) * 680 + localPlayer.vy * 0.3,
    predicted: true
  };

  pendingShots.set(shotId, now);
  predictedProjectiles.set(shotId, {
    ...predicted,
    startedAt: now,
    expiresAt: now + 700
  });
  room.send("shoot", { shotId });
}

function showShotPing(data) {
  const startedAt = pendingShots.get(data.shotId);
  if (!startedAt) return;

  const now = performance.now();
  pendingShots.delete(data.shotId);
  shotPingEl.textContent = `Shoot ping: ${Math.round(now - startedAt)} ms`;

  const predicted = predictedProjectiles.get(data.shotId);
  if (predicted) {
    predictedProjectiles.delete(data.shotId);
  }
}

function loop(now) {
  const dt = Math.min(0.05, (now - lastFrame) / 1000);
  lastFrame = now;

  updateLocalInput(dt);

  draw(now);
  requestAnimationFrame(loop);
}

function draw(now) {
  ctx.clearRect(0, 0, canvas.width, canvas.height);
  ctx.save();
  ctx.scale(devicePixelRatio, devicePixelRatio);

  const viewWidth = canvas.width / devicePixelRatio;
  const viewHeight = canvas.height / devicePixelRatio;
  const focus = localPlayer || { x: world.width / 2, y: world.height / 2 };

  camera.x += (focus.x - viewWidth / 2 - camera.x) * 0.12;
  camera.y += (focus.y - viewHeight / 2 - camera.y) * 0.12;
  camera.x = clamp(camera.x, 0, Math.max(0, world.width - viewWidth));
  camera.y = clamp(camera.y, 0, Math.max(0, world.height - viewHeight));

  ctx.translate(-camera.x, -camera.y);
  drawArena();

  const remoteFrame = sampleSnapshot(now + serverTimeOffset - INTERPOLATION_DELAY);
  updateDriftSmoke(
    localPlayer ? [...remoteFrame.players.filter(player => player.id !== myId), localPlayer] : remoteFrame.players,
    now
  );
  drawDriftSmoke(now);
  drawSupplyBoxes(remoteFrame.supplyBoxes, now);
  const renderedProjectileIds = new Set();

  for (const projectile of remoteFrame.projectiles) {
    if (predictedProjectiles.has(projectile.id)) continue;
    renderedProjectileIds.add(projectile.id);
    drawProjectile(projectile);
  }

  for (const projectile of predictedProjectiles.values()) {
    if (renderedProjectileIds.has(projectile.id) || now > projectile.expiresAt) {
      predictedProjectiles.delete(projectile.id);
      continue;
    }
    drawProjectile(predictedProjectile(projectile, now));
  }

  for (const player of remoteFrame.players) {
    if (player.id !== myId) drawKart(player, false);
  }

  if (localPlayer) drawKart(localPlayer, true);

  drawMinimap(viewWidth, remoteFrame.players);
  ctx.restore();
}

function drawArena() {
  ctx.fillStyle = "#2a3431";
  ctx.fillRect(0, 0, world.width, world.height);

  ctx.strokeStyle = "rgba(255,255,255,0.08)";
  ctx.lineWidth = 2;
  for (let x = 0; x <= world.width; x += 80) {
    ctx.beginPath();
    ctx.moveTo(x, 0);
    ctx.lineTo(x, world.height);
    ctx.stroke();
  }
  for (let y = 0; y <= world.height; y += 80) {
    ctx.beginPath();
    ctx.moveTo(0, y);
    ctx.lineTo(world.width, y);
    ctx.stroke();
  }

  ctx.strokeStyle = "#d9b64f";
  ctx.lineWidth = 8;
  ctx.strokeRect(18, 18, world.width - 36, world.height - 36);

  ctx.fillStyle = "rgba(255,255,255,0.08)";
  for (const obstacle of [
    [360, 250, 180, 56],
    [980, 210, 240, 56],
    [690, 560, 220, 56],
    [260, 710, 170, 56],
    [1160, 720, 170, 56]
  ]) {
    roundRect(...obstacle, 8);
    ctx.fill();
  }
}

function drawKart(player, isLocal) {
  if (kartSpriteReady) {
    drawKartSprite(player, isLocal);
  } else {
    drawFallbackKart(player, isLocal);
  }

  drawPlayerHud(player);
}

function drawKartSprite(player, isLocal) {
  ctx.save();
  ctx.translate(player.x, player.y);
  ctx.rotate(player.angle - Math.PI / 2);

  if (player.respawning) {
    ctx.globalAlpha = 0.38;
  }

  ctx.shadowColor = isLocal ? "rgba(255, 255, 255, 0.45)" : player.color;
  ctx.shadowBlur = isLocal ? 14 : 8;
  ctx.drawImage(
    kartSprite,
    -KART_SPRITE_SIZE / 2,
    -KART_SPRITE_SIZE / 2,
    KART_SPRITE_SIZE,
    KART_SPRITE_SIZE
  );
  ctx.restore();

  ctx.save();
  ctx.strokeStyle = isLocal ? "#ffffff" : player.color;
  ctx.lineWidth = isLocal ? 3 : 2;
  ctx.globalAlpha = isLocal ? 0.9 : 0.65;
  ctx.beginPath();
  ctx.arc(player.x, player.y, 29, 0, Math.PI * 2);
  ctx.stroke();
  ctx.restore();
}

function drawFallbackKart(player, isLocal) {
  ctx.save();
  ctx.translate(player.x, player.y);
  ctx.rotate(player.angle);

  ctx.fillStyle = player.respawning ? "rgba(255,255,255,0.28)" : player.color;
  roundRect(-25, -16, 50, 32, 7);
  ctx.fill();

  ctx.fillStyle = "#111";
  ctx.fillRect(-14, -22, 11, 8);
  ctx.fillRect(-14, 14, 11, 8);
  ctx.fillRect(8, -22, 11, 8);
  ctx.fillRect(8, 14, 11, 8);

  ctx.fillStyle = isLocal ? "#ffffff" : "#18201f";
  ctx.beginPath();
  ctx.moveTo(28, 0);
  ctx.lineTo(10, -9);
  ctx.lineTo(10, 9);
  ctx.closePath();
  ctx.fill();
  ctx.restore();
}

function drawPlayerHud(player) {
  ctx.fillStyle = "#f7fbfa";
  ctx.font = "13px system-ui";
  ctx.textAlign = "center";
  ctx.fillText(player.name || "P", player.x, player.y - 42);

  ctx.fillStyle = "rgba(0,0,0,0.45)";
  roundRect(player.x - 28, player.y + 36, 56, 7, 4);
  ctx.fill();
  ctx.fillStyle = player.hp > 35 ? "#64d46f" : "#ff5d5d";
  roundRect(player.x - 28, player.y + 36, 56 * clamp(player.hp / 100, 0, 1), 7, 4);
  ctx.fill();
}

function drawProjectile(projectile) {
  ctx.fillStyle = "#ffef82";
  ctx.beginPath();
  ctx.arc(projectile.x, projectile.y, 6, 0, Math.PI * 2);
  ctx.fill();

  ctx.strokeStyle = "rgba(255,239,130,0.4)";
  ctx.lineWidth = 3;
  ctx.beginPath();
  ctx.arc(projectile.x, projectile.y, 12, 0, Math.PI * 2);
  ctx.stroke();
}

function updateDriftSmoke(players, now) {
  for (const player of players || []) {
    if (player.respawning) continue;

    const speed = Math.hypot(player.vx || 0, player.vy || 0);
    const isTurning = Math.abs(player.turning || 0) > 0.5;
    if (!isTurning || speed < 170) continue;

    const lastSmokeAt = player.lastSmokeAt || 0;
    if (now - lastSmokeAt < 34) continue;
    player.lastSmokeAt = now;

    const rearX = player.x - Math.cos(player.angle) * 30;
    const rearY = player.y - Math.sin(player.angle) * 30;
    const side = player.turning > 0 ? -1 : 1;
    const sideX = Math.cos(player.angle + Math.PI / 2) * side * 14;
    const sideY = Math.sin(player.angle + Math.PI / 2) * side * 14;

    for (let i = 0; i < 2; i += 1) {
      driftSmokeParticles.push({
        x: rearX + sideX + (Math.random() - 0.5) * 14,
        y: rearY + sideY + (Math.random() - 0.5) * 14,
        vx: -Math.cos(player.angle) * 34 + (Math.random() - 0.5) * 26,
        vy: -Math.sin(player.angle) * 34 + (Math.random() - 0.5) * 26,
        rotation: Math.random() * Math.PI * 2,
        spin: (Math.random() - 0.5) * 1.5,
        size: DRIFT_SMOKE_SIZE * (0.9 + Math.random() * 0.65),
        bornAt: now,
        life: 500
      });
    }
  }

  while (driftSmokeParticles.length > 320) {
    driftSmokeParticles.shift();
  }
}

function drawDriftSmoke(now) {
  for (let i = driftSmokeParticles.length - 1; i >= 0; i -= 1) {
    const particle = driftSmokeParticles[i];
    const age = now - particle.bornAt;
    if (age >= particle.life) {
      driftSmokeParticles.splice(i, 1);
      continue;
    }

    const t = age / particle.life;
    const dt = 1 / 60;
    particle.x += particle.vx * dt;
    particle.y += particle.vy * dt;
    particle.rotation += particle.spin * dt;

    const alpha = (1 - t) * 0.62;
    const size = particle.size * (0.75 + t * 0.85);

    ctx.save();
    ctx.globalAlpha = alpha;
    ctx.translate(particle.x, particle.y);
    ctx.rotate(particle.rotation);

    if (driftSmokeSpriteReady) {
      ctx.drawImage(driftSmokeSprite, -size / 2, -size / 2, size, size);
    } else {
      ctx.fillStyle = "rgba(220, 226, 220, 0.7)";
      ctx.beginPath();
      ctx.arc(0, 0, size / 2, 0, Math.PI * 2);
      ctx.fill();
    }

    ctx.restore();
  }
}

function drawSupplyBoxes(supplyBoxes, now) {
  for (const supplyBox of supplyBoxes || []) {
    if (!supplyBox.active) continue;

    const phase = now / 650 + Number(supplyBox.id) * 0.85;
    const bob = Math.sin(phase);
    const yOffset = bob * 8;
    const downwardAmount = (bob + 1) / 2;
    const scale = 1 - downwardAmount * 0.18;
    const size = SUPPLY_BOX_SIZE * scale;
    const ringRadius = 28 * scale;

    ctx.save();
    ctx.translate(supplyBox.x, supplyBox.y + yOffset);
    ctx.shadowColor = "rgba(106, 255, 141, 0.42)";
    ctx.shadowBlur = 12 + (1 - downwardAmount) * 6;

    if (supplyBoxSpriteReady) {
      ctx.drawImage(
        supplyBoxSprite,
        -size / 2,
        -size / 2,
        size,
        size
      );
    } else {
      ctx.fillStyle = "#46d86f";
      roundRect(-18 * scale, -18 * scale, 36 * scale, 36 * scale, 7 * scale);
      ctx.fill();
      ctx.fillStyle = "#f7fbfa";
      ctx.fillRect(-4 * scale, -13 * scale, 8 * scale, 26 * scale);
      ctx.fillRect(-13 * scale, -4 * scale, 26 * scale, 8 * scale);
    }

    ctx.restore();

    ctx.save();
    ctx.strokeStyle = `rgba(116, 255, 154, ${0.42 + (1 - downwardAmount) * 0.24})`;
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.arc(supplyBox.x, supplyBox.y + yOffset, ringRadius, 0, Math.PI * 2);
    ctx.stroke();
    ctx.restore();
  }
}

function drawMinimap(viewWidth, players) {
  const mapWidth = 170;
  const mapHeight = Math.round((world.height / world.width) * mapWidth);
  const padding = 14;
  const x = camera.x + viewWidth - mapWidth - padding;
  const y = camera.y + padding;
  const scaleX = mapWidth / world.width;
  const scaleY = mapHeight / world.height;

  ctx.save();
  ctx.fillStyle = "rgba(7, 12, 12, 0.72)";
  ctx.strokeStyle = "rgba(255, 255, 255, 0.28)";
  ctx.lineWidth = 1;
  roundRect(x, y, mapWidth, mapHeight, 8);
  ctx.fill();
  ctx.stroke();

  ctx.strokeStyle = "rgba(255, 255, 255, 0.12)";
  ctx.strokeRect(x + 6, y + 6, mapWidth - 12, mapHeight - 12);

  for (const player of players) {
    if (player.id !== myId) drawMinimapDot(player, x, y, scaleX, scaleY, false);
  }

  if (localPlayer) {
    drawMinimapDot(localPlayer, x, y, scaleX, scaleY, true);
  }

  ctx.restore();
}

function drawMinimapDot(player, mapX, mapY, scaleX, scaleY, isLocal) {
  const dotX = mapX + player.x * scaleX;
  const dotY = mapY + player.y * scaleY;

  ctx.fillStyle = isLocal ? "#ffffff" : player.color;
  ctx.strokeStyle = isLocal ? "#1b2422" : "rgba(255, 255, 255, 0.85)";
  ctx.lineWidth = isLocal ? 2 : 1;
  ctx.beginPath();
  ctx.arc(dotX, dotY, isLocal ? 5 : 4, 0, Math.PI * 2);
  ctx.fill();
  ctx.stroke();
}

function sampleSnapshot(renderTime) {
  if (snapshotBuffer.length === 0) {
    return { players: [], projectiles: [], supplyBoxes: [] };
  }

  if (snapshotBuffer.length === 1 || renderTime <= snapshotBuffer[0].time) {
    return snapshotBuffer[0];
  }

  let older = snapshotBuffer[0];
  let newer = snapshotBuffer[snapshotBuffer.length - 1];

  for (let i = 0; i < snapshotBuffer.length - 1; i += 1) {
    if (snapshotBuffer[i].time <= renderTime && snapshotBuffer[i + 1].time >= renderTime) {
      older = snapshotBuffer[i];
      newer = snapshotBuffer[i + 1];
      break;
    }
  }

  if (renderTime >= newer.time) {
    return extrapolateSnapshot(newer, (renderTime - newer.time) / 1000);
  }

  const span = Math.max(1, newer.time - older.time);
  const t = clamp((renderTime - older.time) / span, 0, 1);

  return {
    time: renderTime,
    players: interpolateEntities(older.players, newer.players, t, interpolatePlayer),
    projectiles: interpolateEntities(older.projectiles, newer.projectiles, t, interpolateProjectile),
    supplyBoxes: newer.supplyBoxes || []
  };
}

function extrapolateSnapshot(snapshot, dt) {
  const cappedDt = Math.min(dt, 0.08);

  return {
    time: snapshot.time + cappedDt * 1000,
    supplyBoxes: snapshot.supplyBoxes || [],
    players: snapshot.players.map(player => ({
      ...player,
      x: player.x + (player.vx || 0) * cappedDt,
      y: player.y + (player.vy || 0) * cappedDt
    })),
    projectiles: snapshot.projectiles.map(projectile => ({
      ...projectile,
      x: projectile.x + (projectile.vx || 0) * cappedDt,
      y: projectile.y + (projectile.vy || 0) * cappedDt
    }))
  };
}

function interpolateEntities(olderEntities, newerEntities, t, interpolateOne) {
  const olderById = new Map(olderEntities.map(entity => [entity.id, entity]));

  return newerEntities.map(newer => {
    const older = olderById.get(newer.id);
    return older ? interpolateOne(older, newer, t) : newer;
  });
}

function interpolatePlayer(older, newer, t) {
  return {
    ...newer,
    x: lerp(older.x, newer.x, t),
    y: lerp(older.y, newer.y, t),
    angle: lerpAngle(older.angle, newer.angle, t),
    hp: Math.round(lerp(older.hp, newer.hp, t))
  };
}

function interpolateProjectile(older, newer, t) {
  return {
    ...newer,
    x: lerp(older.x, newer.x, t),
    y: lerp(older.y, newer.y, t)
  };
}

function predictedProjectile(projectile, now) {
  const elapsed = (now - projectile.startedAt) / 1000;

  return {
    ...projectile,
    x: projectile.x + projectile.vx * elapsed,
    y: projectile.y + projectile.vy * elapsed
  };
}

function renderScoreboard(players) {
  scoreboardEl.innerHTML = players
    .sort((a, b) => b.score - a.score)
    .map(
      player => `
        <span class="player-chip">
          <span class="swatch" style="background:${player.color}"></span>
          ${player.name}${player.id === myId ? " (you)" : ""}: ${player.score} · ${player.hp}hp
        </span>
      `
    )
    .join("");
}

function resize() {
  const rect = canvas.getBoundingClientRect();
  canvas.width = Math.floor(rect.width * devicePixelRatio);
  canvas.height = Math.floor(rect.height * devicePixelRatio);
}

function roundRect(x, y, width, height, radius) {
  ctx.beginPath();
  ctx.roundRect(x, y, width, height, radius);
}

function lerp(a, b, t) {
  return a + (b - a) * t;
}

function lerpAngle(a, b, t) {
  const delta = Math.atan2(Math.sin(b - a), Math.cos(b - a));
  return a + delta * t;
}

function clamp(value, min, max) {
  return Math.max(min, Math.min(max, value));
}
